<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Project rules

- All artist photos/videos live as CDN asset pointers in `src/assets/media/` and are referenced only through `src/lib/media.ts` — one manifest keeps alt text, captions and verified facts together.
- Verified artist facts (venues, collaborations, contact) live only in the `artist` object in `src/lib/media.ts`; components read from it so nothing unverified is hard-coded in UI.
- Booking form rules (fields, event types, spam limits) live in `src/lib/booking-schema.ts` and are shared by the client form, the `submitBooking` server function and the tests.
- Public booking inserts go through the `submitBooking` server function using the service-role client after validation and spam checks; the `bookings` table has no anon grants or insert policy.
- Admin access is decided by the `admin` row in `public.user_roles` (checked with `has_role` in RLS); the first account ever created is auto-granted admin by a trigger on `auth.users`.
- The admin dashboard reads/updates bookings with the browser client under RLS; it lives under the `_authenticated` layout (`ssr: false`).
- Section components live in `src/components/site/` and are reused across routes; each nav section is its own route file.
- Motion uses small in-house hooks in `src/hooks/use-motion.ts` (IntersectionObserver / rAF) instead of an animation library to keep JS light.
