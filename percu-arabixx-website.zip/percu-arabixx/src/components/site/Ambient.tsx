import { useEffect, useRef, useState } from "react";
import { cn } from "@/lib/utils";

/** Short rhythmic intro shown once per session. */
export function Loader() {
  const [phase, setPhase] = useState<"hidden" | "show" | "leaving">("hidden");

  useEffect(() => {
    if (sessionStorage.getItem("pa-intro")) return;
    sessionStorage.setItem("pa-intro", "1");
    setPhase("show");
    const t1 = setTimeout(() => setPhase("leaving"), 1500);
    const t2 = setTimeout(() => setPhase("hidden"), 2400);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
    };
  }, []);

  if (phase === "hidden") return null;

  return (
    <div
      className={cn(
        "fixed inset-0 z-[100] flex flex-col items-center justify-center gap-8 bg-background transition-[clip-path] duration-[900ms]",
        phase === "leaving" ? "[clip-path:inset(0_0_100%_0)]" : "[clip-path:inset(0_0_0_0)]",
      )}
      aria-hidden
    >
      <div className="flex h-14 items-end gap-1.5">
        {[0, 1, 2, 3, 4, 5, 6].map((i) => (
          <span
            key={i}
            className="block h-full w-1.5 origin-bottom animate-bar rounded-full bg-primary"
            style={{ animationDelay: `${i * 110}ms` }}
          />
        ))}
      </div>
      <p className="eyebrow text-muted-foreground">Percu Arabixx · Live percussion</p>
    </div>
  );
}

/** Soft spotlight cursor for fine pointers only. */
export function Cursor() {
  const dot = useRef<HTMLDivElement>(null);
  const ring = useRef<HTMLDivElement>(null);
  const [enabled, setEnabled] = useState(false);

  useEffect(() => {
    if (!window.matchMedia("(pointer: fine)").matches) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    setEnabled(true);
  }, []);

  useEffect(() => {
    if (!enabled) return;
    let x = window.innerWidth / 2;
    let y = window.innerHeight / 2;
    let rx = x;
    let ry = y;
    let raf = 0;
    const move = (e: PointerEvent) => {
      x = e.clientX;
      y = e.clientY;
      const target = e.target as HTMLElement | null;
      const interactive = !!target?.closest("a, button, [role=button], input, select, textarea, [data-cursor]");
      ring.current?.setAttribute("data-active", interactive ? "true" : "false");
      const label = target?.closest<HTMLElement>("[data-cursor]")?.dataset["cursor"] ?? "";
      if (ring.current) ring.current.dataset["label"] = label;
    };
    const tick = () => {
      rx += (x - rx) * 0.18;
      ry += (y - ry) * 0.18;
      if (dot.current) dot.current.style.transform = `translate3d(${x}px, ${y}px, 0)`;
      if (ring.current) ring.current.style.transform = `translate3d(${rx}px, ${ry}px, 0)`;
      raf = requestAnimationFrame(tick);
    };
    window.addEventListener("pointermove", move);
    raf = requestAnimationFrame(tick);
    return () => {
      window.removeEventListener("pointermove", move);
      cancelAnimationFrame(raf);
    };
  }, [enabled]);

  if (!enabled) return null;

  return (
    <>
      <div ref={dot} className="pointer-events-none fixed left-0 top-0 z-[90] -ml-1 -mt-1 size-2 rounded-full bg-primary mix-blend-difference" aria-hidden />
      <div
        ref={ring}
        className="group pointer-events-none fixed left-0 top-0 z-[89] -ml-5 -mt-5 flex size-10 items-center justify-center rounded-full border border-primary/60 transition-[width,height,margin,background-color] duration-300 data-[active=true]:-ml-8 data-[active=true]:-mt-8 data-[active=true]:size-16 data-[active=true]:bg-primary/10"
        aria-hidden
      />
    </>
  );
}
