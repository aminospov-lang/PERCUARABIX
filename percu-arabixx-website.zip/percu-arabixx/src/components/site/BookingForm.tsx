import { useEffect, useMemo, useState, type ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { format } from "date-fns";
import { ArrowLeft, ArrowRight, CalendarIcon, Check, Loader2, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { artist } from "@/lib/media";
import { BUDGETS, DISCOVERY_SOURCES, DURATIONS, EVENT_TYPES, makeBookingSchema } from "@/lib/booking-schema";
import { submitBooking } from "@/lib/bookings.functions";
import { cn } from "@/lib/utils";

type FormState = {
  full_name: string;
  email: string;
  phone: string;
  company: string;
  event_type: string;
  event_date: string;
  event_location: string;
  guest_count: string;
  duration: string;
  budget_range: string;
  message: string;
  discovery_source: string;
  website: string;
};

const EMPTY: FormState = {
  full_name: "",
  email: "",
  phone: "",
  company: "",
  event_type: "",
  event_date: "",
  event_location: "",
  guest_count: "",
  duration: "",
  budget_range: "",
  message: "",
  discovery_source: "",
  website: "",
};

const STEPS = [
  { title: "The event", fields: ["event_type", "event_date", "event_location", "guest_count", "duration"] },
  { title: "The vision", fields: ["budget_range", "message", "discovery_source"] },
  { title: "Your details", fields: ["full_name", "email", "phone", "company"] },
] as const;

const fieldBase =
  "w-full border-0 border-b border-input bg-transparent px-0 py-4 text-lg text-foreground placeholder:text-muted-foreground/60 focus:border-primary focus:outline-none focus:ring-0 transition-colors md:text-xl";

function Field({ label, error, optional, children, htmlFor }: { label: string; error?: string | undefined; optional?: boolean; children: ReactNode; htmlFor?: string }) {
  return (
    <div className="flex flex-col">
      <label htmlFor={htmlFor} className="eyebrow flex items-center justify-between text-muted-foreground">
        <span>{label}</span>
        {optional && <span className="text-[0.6rem] tracking-[0.2em] text-muted-foreground/60">Optional</span>}
      </label>
      {children}
      {error && <p className="mt-2 text-sm text-destructive" role="alert">{error}</p>}
    </div>
  );
}

function Chip({ active, onClick, children }: { active: boolean; onClick: () => void; children: ReactNode }) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={cn(
        "min-h-12 rounded-full border px-5 py-2 text-sm font-semibold transition-colors duration-300",
        active ? "border-primary bg-primary text-primary-foreground" : "border-border text-foreground/80 hover:border-foreground/50",
      )}
    >
      {children}
    </button>
  );
}

export function BookingForm() {
  const [step, setStep] = useState(0);
  const [form, setForm] = useState<FormState>(EMPTY);
  const [errors, setErrors] = useState<Partial<Record<keyof FormState, string>>>({});
  const [startedAt, setStartedAt] = useState(0);
  const [status, setStatus] = useState<"idle" | "sending" | "done">("idle");
  const [serverError, setServerError] = useState<string | null>(null);
  const [dateOpen, setDateOpen] = useState(false);
  const send = useServerFn(submitBooking);

  useEffect(() => setStartedAt(Date.now()), []);

  const set = <K extends keyof FormState>(k: K, v: FormState[K]) => {
    setForm((f) => ({ ...f, [k]: v }));
    setErrors((e) => ({ ...e, [k]: undefined }));
  };

  const payload = useMemo(
    () => ({
      full_name: form.full_name,
      email: form.email,
      phone: form.phone,
      company: form.company || undefined,
      event_type: form.event_type || undefined,
      event_date: form.event_date,
      event_location: form.event_location,
      guest_count: form.guest_count === "" ? undefined : form.guest_count,
      duration: form.duration || undefined,
      budget_range: form.budget_range || undefined,
      message: form.message || undefined,
      discovery_source: form.discovery_source || undefined,
      website: form.website,
      started_at: startedAt || Date.now(),
    }),
    [form, startedAt],
  );

  const validate = (fields: readonly string[]) => {
    const result = makeBookingSchema().safeParse(payload);
    if (result.success) return true;
    const fe = result.error.flatten().fieldErrors as Record<string, string[] | undefined>;
    const next: Partial<Record<keyof FormState, string>> = {};
    for (const f of fields) if (fe[f]?.[0]) next[f as keyof FormState] = fe[f]![0];
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const nextStep = () => {
    if (validate(STEPS[step]!.fields)) {
      setStep((s) => Math.min(STEPS.length - 1, s + 1));
      document.getElementById("booking")?.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  const submit = async () => {
    if (!validate(STEPS.flatMap((s) => s.fields))) {
      const firstBad = STEPS.findIndex((s) => s.fields.some((f) => {
        const r = makeBookingSchema().safeParse(payload);
        return !r.success && (r.error.flatten().fieldErrors as Record<string, unknown>)[f];
      }));
      if (firstBad >= 0) setStep(firstBad);
      return;
    }
    setStatus("sending");
    setServerError(null);
    try {
      const res = await send({ data: payload });
      if (res.ok) {
        setStatus("done");
        window.scrollTo({ top: 0, behavior: "smooth" });
      } else {
        setServerError(res.error);
        setStatus("idle");
      }
    } catch (err) {
      console.error(err);
      setServerError("Something went wrong. Please check your details or message us on WhatsApp.");
      setStatus("idle");
    }
  };

  if (status === "done") {
    return (
      <div className="mx-auto flex max-w-3xl flex-col items-center py-24 text-center animate-in fade-in slide-in-from-bottom-6 duration-1000">
        <span className="flex size-20 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-glow">
          <Check className="size-9" />
        </span>
        <h2 className="font-display mt-10 text-[16vw] md:text-9xl">Request received</h2>
        <p className="mt-6 max-w-lg text-lg text-foreground/75">
          Thank you. Your booking request has been received. Percu Arabixx's team will get back to you shortly.
        </p>
        <div className="mt-10 flex flex-col gap-3 sm:flex-row">
          <Button asChild variant="hero" size="xl">
            <Link to="/">Back to home</Link>
          </Button>
          <Button asChild variant="ghostLight" size="xl">
            <a href={artist.whatsappUrl} target="_blank" rel="noreferrer">
              <MessageCircle /> Chat on WhatsApp
            </a>
          </Button>
        </div>
      </div>
    );
  }

  const selectedDate = form.event_date ? new Date(`${form.event_date}T12:00:00`) : undefined;
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  return (
    <div id="booking" className="mx-auto max-w-4xl scroll-mt-28">
      {/* Progress */}
      <ol className="mb-14 grid grid-cols-3 gap-3" aria-label="Booking steps">
        {STEPS.map((s, i) => (
          <li key={s.title}>
            <button type="button" onClick={() => i < step && setStep(i)} disabled={i > step} className="w-full text-left disabled:cursor-default">
              <span className={cn("block h-0.5 w-full transition-colors duration-500", i <= step ? "bg-primary" : "bg-border")} />
              <span className={cn("eyebrow mt-3 block", i === step ? "text-foreground" : "text-muted-foreground")}>
                <span className="text-primary">0{i + 1}</span> <span className="hidden sm:inline">{s.title}</span>
              </span>
            </button>
          </li>
        ))}
      </ol>

      <form
        noValidate
        onSubmit={(e) => {
          e.preventDefault();
          if (step < STEPS.length - 1) nextStep();
          else void submit();
        }}
        className="flex flex-col gap-12"
      >
        {/* Honeypot — hidden from people, irresistible to bots */}
        <div className="absolute -left-[9999px] h-0 w-0 overflow-hidden" aria-hidden>
          <label>
            Website
            <input tabIndex={-1} autoComplete="off" value={form.website} onChange={(e) => set("website", e.target.value)} />
          </label>
        </div>

        <h2 className="font-display text-6xl md:text-8xl" key={step}>
          <span className="block animate-in fade-in slide-in-from-bottom-4 duration-700">{STEPS[step]!.title}</span>
        </h2>

        {step === 0 && (
          <div className="flex flex-col gap-12 animate-in fade-in duration-700">
            <Field label="Event type" error={errors.event_type}>
              <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
                {EVENT_TYPES.map((t) => (
                  <button
                    key={t.value}
                    type="button"
                    onClick={() => set("event_type", t.value)}
                    aria-pressed={form.event_type === t.value}
                    className={cn(
                      "min-h-16 rounded-sm border px-4 py-3 text-left text-sm font-semibold transition-colors duration-300",
                      form.event_type === t.value ? "border-primary bg-primary/10 text-primary" : "border-border hover:border-foreground/40",
                    )}
                  >
                    {t.label}
                  </button>
                ))}
              </div>
            </Field>

            <div className="grid gap-12 md:grid-cols-2">
              <Field label="Event date" error={errors.event_date}>
                <Popover open={dateOpen} onOpenChange={setDateOpen}>
                  <PopoverTrigger asChild>
                    <button type="button" className={cn(fieldBase, "flex items-center justify-between text-left", !form.event_date && "text-muted-foreground/60")}>
                      {selectedDate ? format(selectedDate, "EEEE d MMMM yyyy") : "Choose a date"}
                      <CalendarIcon className="size-5 text-primary" />
                    </button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto border-border bg-popover p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={selectedDate}
                      onSelect={(d) => {
                        if (d) set("event_date", format(d, "yyyy-MM-dd"));
                        setDateOpen(false);
                      }}
                      disabled={{ before: today }}
                      className="pointer-events-auto bg-popover [--cell-size:2.6rem]"
                    />
                  </PopoverContent>
                </Popover>
              </Field>

              <Field label="Event location" error={errors.event_location} htmlFor="event_location">
                <input id="event_location" className={fieldBase} placeholder="City, venue" value={form.event_location} onChange={(e) => set("event_location", e.target.value)} autoComplete="address-level2" />
              </Field>
            </div>

            <div className="grid gap-12 md:grid-cols-2">
              <Field label="Estimated guests" error={errors.guest_count} optional htmlFor="guest_count">
                <input id="guest_count" className={fieldBase} inputMode="numeric" placeholder="e.g. 250" value={form.guest_count} onChange={(e) => set("guest_count", e.target.value.replace(/[^\d]/g, ""))} />
              </Field>
              <Field label="Performance duration" error={errors.duration} optional>
                <div className="mt-4 flex flex-wrap gap-2">
                  {DURATIONS.map((d) => (
                    <Chip key={d} active={form.duration === d} onClick={() => set("duration", form.duration === d ? "" : d)}>
                      {d}
                    </Chip>
                  ))}
                </div>
              </Field>
            </div>
          </div>
        )}

        {step === 1 && (
          <div className="flex flex-col gap-12 animate-in fade-in duration-700">
            <Field label="Budget range" error={errors.budget_range} optional>
              <div className="mt-4 flex flex-wrap gap-2">
                {BUDGETS.map((b) => (
                  <Chip key={b} active={form.budget_range === b} onClick={() => set("budget_range", form.budget_range === b ? "" : b)}>
                    {b}
                  </Chip>
                ))}
              </div>
            </Field>
            <Field label="Tell us about the event" error={errors.message} optional htmlFor="message">
              <textarea id="message" rows={4} className={cn(fieldBase, "resize-none")} placeholder="The vibe, the music, key moments (entrance, cake, peak hour)…" value={form.message} onChange={(e) => set("message", e.target.value)} maxLength={2000} />
            </Field>
            <Field label="How did you discover Percu Arabixx?" error={errors.discovery_source} optional>
              <Select value={form.discovery_source} onValueChange={(v) => set("discovery_source", v)}>
                <SelectTrigger className="mt-2 h-14 rounded-none border-0 border-b border-input bg-transparent px-0 text-lg shadow-none focus:ring-0">
                  <SelectValue placeholder="Choose one" />
                </SelectTrigger>
                <SelectContent>
                  {DISCOVERY_SOURCES.map((s) => (
                    <SelectItem key={s} value={s}>
                      {s}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
          </div>
        )}

        {step === 2 && (
          <div className="grid gap-12 animate-in fade-in duration-700 md:grid-cols-2">
            <Field label="Full name" error={errors.full_name} htmlFor="full_name">
              <input id="full_name" className={fieldBase} value={form.full_name} onChange={(e) => set("full_name", e.target.value)} autoComplete="name" placeholder="Your name" />
            </Field>
            <Field label="Email" error={errors.email} htmlFor="email">
              <input id="email" type="email" className={fieldBase} value={form.email} onChange={(e) => set("email", e.target.value)} autoComplete="email" placeholder="you@example.com" inputMode="email" />
            </Field>
            <Field label="Phone / WhatsApp" error={errors.phone} htmlFor="phone">
              <input id="phone" type="tel" className={fieldBase} value={form.phone} onChange={(e) => set("phone", e.target.value)} autoComplete="tel" placeholder="+212 6 …" inputMode="tel" />
            </Field>
            <Field label="Company / organization" error={errors.company} optional htmlFor="company">
              <input id="company" className={fieldBase} value={form.company} onChange={(e) => set("company", e.target.value)} autoComplete="organization" placeholder="If applicable" />
            </Field>
          </div>
        )}

        {serverError && (
          <p className="rounded-sm border border-destructive/40 bg-destructive/10 px-4 py-3 text-sm text-destructive" role="alert">
            {serverError}
          </p>
        )}

        <div className="sticky bottom-3 z-10 flex items-center justify-between gap-3 rounded-full border border-border bg-background/85 p-2 backdrop-blur-xl md:static md:border-0 md:bg-transparent md:p-0">
          {step > 0 ? (
            <Button type="button" variant="ghostLight" size="xl" onClick={() => setStep((s) => s - 1)} className="px-5 md:px-8">
              <ArrowLeft /> <span className="hidden sm:inline">Back</span>
            </Button>
          ) : (
            <a href={artist.whatsappUrl} target="_blank" rel="noreferrer" className="eyebrow flex items-center gap-2 px-4 text-muted-foreground hover:text-primary">
              <MessageCircle className="size-4" /> <span className="hidden sm:inline">Prefer WhatsApp?</span>
            </a>
          )}
          {step < STEPS.length - 1 ? (
            <Button type="submit" variant="hero" size="xl" className="flex-1 sm:flex-none">
              Continue <ArrowRight />
            </Button>
          ) : (
            <Button type="submit" variant="hero" size="xl" disabled={status === "sending"} className="flex-1 sm:flex-none">
              {status === "sending" ? (
                <>
                  <Loader2 className="animate-spin" /> Sending
                </>
              ) : (
                <>Send request</>
              )}
            </Button>
          )}
        </div>
      </form>
    </div>
  );
}
