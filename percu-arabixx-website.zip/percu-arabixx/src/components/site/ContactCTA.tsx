import { Link } from "@tanstack/react-router";
import { Instagram, Mail, MessageCircle } from "lucide-react";
import { artist, photos } from "@/lib/media";
import { Button } from "@/components/ui/button";
import { Magnetic } from "./Magnetic";
import { MaskedLines, Reveal } from "./Reveal";

export function ContactCTA() {
  return (
    <section className="grain relative overflow-hidden" aria-labelledby="cta-title">
      <img src={photos.gnawaNight.src} srcSet={photos.gnawaNight.srcSet} sizes="100vw" alt="" loading="lazy" className="absolute inset-0 h-full w-full animate-ken-burns object-cover opacity-45" />
      <div className="absolute inset-0 bg-background/60" />
      <div className="bg-stage-glow absolute inset-0" />

      <div className="relative mx-auto max-w-[1600px] px-5 pb-16 pt-32 md:px-10 md:pb-20 md:pt-48">
        <Reveal>
          <p className="eyebrow text-primary">Bookings open</p>
        </Reveal>
        <MaskedLines
          as="h2"
          lines={[<span key="a" id="cta-title">Let's create</span>, <span key="b">the <span className="font-editorial normal-case text-primary">moment.</span></span>]}
          className="font-display mt-6 text-[19vw] leading-[0.82] md:text-[12vw] xl:text-[13rem]"
        />

        <div className="mt-14 flex flex-col gap-10 md:flex-row md:items-end md:justify-between">
          <Magnetic>
            <Button asChild variant="hero" size="xl" className="h-16 w-full px-12 text-sm md:h-20 md:w-auto">
              <Link to="/book">Book Percu Arabixx</Link>
            </Button>
          </Magnetic>

          <ul className="grid gap-4 sm:grid-cols-3 md:gap-10">
            <li>
              <a href={artist.whatsappUrl} target="_blank" rel="noreferrer" className="group block">
                <span className="eyebrow flex items-center gap-2 text-muted-foreground"><MessageCircle className="size-4" /> WhatsApp</span>
                <span className="mt-2 block text-lg transition-colors group-hover:text-primary">{artist.phoneDisplay}</span>
              </a>
            </li>
            <li>
              <a href={artist.instagramUrl} target="_blank" rel="noreferrer" className="group block">
                <span className="eyebrow flex items-center gap-2 text-muted-foreground"><Instagram className="size-4" /> Instagram</span>
                <span className="mt-2 block text-lg transition-colors group-hover:text-primary">{artist.instagramHandle}</span>
              </a>
            </li>
            {artist.email && (
              <li>
                <a href={`mailto:${artist.email}`} className="group block">
                  <span className="eyebrow flex items-center gap-2 text-muted-foreground"><Mail className="size-4" /> Email</span>
                  <span className="mt-2 block text-lg transition-colors group-hover:text-primary">{artist.email}</span>
                </a>
              </li>
            )}
          </ul>
        </div>
      </div>
    </section>
  );
}

export function SiteFooter() {
  return (
    <footer className="border-t border-border px-5 pb-28 pt-10 md:px-10 md:pb-10">
      <div className="mx-auto flex max-w-[1600px] flex-col justify-between gap-6 text-sm text-muted-foreground md:flex-row md:items-center">
        <p className="font-display text-2xl text-foreground">
          Percu<span className="text-primary">·</span>Arabixx
        </p>
        <nav className="flex flex-wrap gap-x-6 gap-y-2" aria-label="Footer">
          <Link to="/experience" className="hover:text-foreground">Experience</Link>
          <Link to="/events" className="hover:text-foreground">Events</Link>
          <Link to="/gallery" className="hover:text-foreground">Gallery</Link>
          <Link to="/about" className="hover:text-foreground">About</Link>
          <Link to="/book" className="hover:text-foreground">Book</Link>
          <Link to="/admin" className="hover:text-foreground">Team</Link>
        </nav>
        <p>© {new Date().getFullYear()} Percu Arabixx · Larbi Jerkech</p>
      </div>
    </footer>
  );
}
