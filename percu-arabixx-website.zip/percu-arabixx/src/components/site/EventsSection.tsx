import { Link } from "@tanstack/react-router";
import { useRef, useState, type PointerEvent } from "react";
import { ArrowUpRight } from "lucide-react";
import { photos, type Photo } from "@/lib/media";
import { Reveal } from "./Reveal";
import { cn } from "@/lib/utils";

const EVENTS: { title: string; text: string; photo: Photo }[] = [
  { title: "Private events", text: "Luxury celebrations, private parties and exclusive gatherings.", photo: photos.gardenClose },
  { title: "Corporate events", text: "Brand activations, corporate events, launches and professional experiences.", photo: photos.gnawaTroupe },
  { title: "Clubs & nightlife", text: "Clubs, lounges and nightlife venues — high-energy sets alongside the DJ.", photo: photos.laser1 },
  { title: "Festivals", text: "Large-scale festivals, cultural events and music experiences.", photo: photos.gnawaGuests },
  { title: "Weddings & celebrations", text: "Live percussion designed to elevate the atmosphere and create memorable moments.", photo: photos.weddingColor },
  { title: "Brand & special events", text: "Custom performances for brands, productions and unique events.", photo: photos.shokoWide },
];

export function EventsSection() {
  const [active, setActive] = useState<number | null>(null);
  const [pos, setPos] = useState({ x: 0, y: 0 });
  const listRef = useRef<HTMLDivElement>(null);

  const onMove = (e: PointerEvent) => {
    const r = listRef.current?.getBoundingClientRect();
    if (!r) return;
    setPos({ x: e.clientX - r.left, y: e.clientY - r.top });
  };

  return (
    <section className="relative px-5 py-28 md:px-10 md:py-40" aria-labelledby="events-title">
      <div className="mx-auto max-w-[1600px]">
        <div className="flex flex-col justify-between gap-8 md:flex-row md:items-end">
          <div>
            <Reveal>
              <p className="eyebrow text-primary">03 — Where he performs</p>
            </Reveal>
            <Reveal delay={100}>
              <h2 id="events-title" className="font-display mt-4 text-[16vw] md:text-[8vw] xl:text-[8.5rem]">
                Every stage,
                <br />
                <span className="font-editorial normal-case text-primary">its own pulse.</span>
              </h2>
            </Reveal>
          </div>
          <Reveal delay={200} className="max-w-sm text-foreground/70 md:text-lg">
            Each performance is shaped around the room — the guests, the music, the moment you want people to remember.
          </Reveal>
        </div>

        {/* Desktop: editorial index with a cursor-following image */}
        <div ref={listRef} className="relative mt-20 hidden md:block" onPointerMove={onMove} onPointerLeave={() => setActive(null)}>
          {EVENTS.map((ev, i) => (
            <Link
              key={ev.title}
              to="/book"
              onPointerEnter={() => setActive(i)}
              className="group relative grid grid-cols-12 items-center gap-6 border-t border-border py-8 last:border-b"
              data-cursor="Book"
            >
              <span className="eyebrow col-span-1 text-muted-foreground">0{i + 1}</span>
              <h3
                className={cn(
                  "font-display col-span-7 text-7xl transition-[color,transform] duration-500 xl:text-8xl",
                  active === i ? "translate-x-6 text-primary" : active !== null ? "text-foreground/25" : "",
                )}
              >
                {ev.title}
              </h3>
              <p className={cn("col-span-3 text-foreground/70 transition-opacity duration-500", active !== null && active !== i && "opacity-30")}>{ev.text}</p>
              <ArrowUpRight className="col-span-1 ml-auto size-8 text-primary opacity-0 transition-[opacity,transform] duration-500 group-hover:rotate-45 group-hover:opacity-100" />
            </Link>
          ))}

          <div
            className="pointer-events-none absolute left-0 top-0 z-20 h-80 w-60 overflow-hidden shadow-deep transition-[opacity,scale] duration-500"
            style={{
              transform: `translate3d(${pos.x - 120}px, ${pos.y - 160}px, 0) rotate(${active !== null ? (active % 2 ? 4 : -4) : 0}deg)`,
              opacity: active === null ? 0 : 1,
              scale: active === null ? "0.8" : "1",
            }}
            aria-hidden
          >
            {EVENTS.map((ev, i) => (
              <img
                key={ev.title}
                src={ev.photo.src}
                alt=""
                loading="lazy"
                className={cn("absolute inset-0 h-full w-full object-cover transition-opacity duration-500", active === i ? "opacity-100" : "opacity-0")}
              />
            ))}
          </div>
        </div>

        {/* Mobile: image-led chapters */}
        <div className="mt-14 flex flex-col gap-14 md:hidden">
          {EVENTS.map((ev, i) => (
            <Link key={ev.title} to="/book" className="group block">
              <Reveal variant="image" className="relative aspect-[4/3] overflow-hidden">
                <img src={ev.photo.src} alt={ev.photo.alt} loading="lazy" className="h-full w-full object-cover" />
                <div className="bg-fade-b absolute inset-0" />
                <span className="font-editorial absolute left-4 top-3 text-4xl text-primary">0{i + 1}</span>
                <h3 className="font-display absolute bottom-4 left-4 right-4 text-5xl">{ev.title}</h3>
              </Reveal>
              <p className="mt-4 text-foreground/70">{ev.text}</p>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
