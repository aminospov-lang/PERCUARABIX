import { useEffect, useRef, useState } from "react";
import { photos, type Photo } from "@/lib/media";
import { useScrollProgress } from "@/hooks/use-motion";
import { Reveal } from "./Reveal";
import { cn } from "@/lib/utils";

type Chapter = { n: string; title: string; line: string; main: Photo; second: Photo; tone: string };

const CHAPTERS: Chapter[] = [
  { n: "01", title: "Live performance", line: "Drum on the shoulder, above the room.", main: photos.shokoDrum, second: photos.laser2, tone: "text-primary" },
  { n: "02", title: "Event energy", line: "The peak arrives when he does.", main: photos.gnawaLead, second: photos.gnawaTroupe, tone: "text-ember" },
  { n: "03", title: "The crowd", line: "Hands up, phones out, nobody sitting down.", main: photos.gnawaGuests, second: photos.weddingColor, tone: "text-primary" },
  { n: "04", title: "The moment", line: "The entrance everyone remembers.", main: photos.bwJoy, second: photos.weddingSmile, tone: "text-ember" },
  { n: "05", title: "The rhythm", line: "Every hit lands with the music.", main: photos.gardenDrum, second: photos.laser3, tone: "text-primary" },
];

function ChapterPanel({ c, index, progress }: { c: Chapter; index: number; progress?: number }) {
  // subtle per-panel drift for the overlapping second image
  const drift = progress !== undefined ? (progress * CHAPTERS.length - index) * 50 : 0;
  return (
    <article className="flex h-full w-[82vw] shrink-0 items-center gap-[3vw] pr-[6vw] lg:w-[68vw]">
      <div className="relative h-[64vh] w-[52%] shrink-0">
        <div className="absolute inset-y-0 left-0 w-[78%] overflow-hidden">
          <img src={c.main.src} srcSet={c.main.srcSet} sizes="35vw" alt={c.main.alt} loading="lazy" className="h-full w-full object-cover" />
          <div className="bg-fade-t absolute inset-0 opacity-30" />
        </div>
        <div
          className="absolute -bottom-[5vh] right-0 h-[30vh] w-[42%] overflow-hidden shadow-deep"
          style={{ transform: `translate3d(0, ${-drift}px, 0)` }}
        >
          <img src={c.second.src} srcSet={c.second.srcSet} sizes="25vw" alt={c.second.alt} loading="lazy" className="h-full w-full object-cover" />
        </div>
      </div>
      <div className="min-w-0 flex-1">
        <span className={cn("font-editorial text-5xl lg:text-6xl", c.tone)}>{c.n}</span>
        <h3 className="font-display mt-3 text-[clamp(3rem,4.6vw,6.5rem)]">{c.title}</h3>
        <p className="mt-5 max-w-xs text-foreground/70 lg:text-lg">{c.line}</p>
      </div>
    </article>
  );
}

export function ExperienceSequence() {
  const section = useRef<HTMLElement>(null);
  const track = useRef<HTMLDivElement>(null);
  const progress = useScrollProgress(section);
  const [distance, setDistance] = useState(0);

  useEffect(() => {
    const measure = () => {
      if (!track.current) return;
      setDistance(Math.max(0, track.current.scrollWidth - window.innerWidth));
    };
    measure();
    window.addEventListener("resize", measure);
    return () => window.removeEventListener("resize", measure);
  }, []);

  return (
    <>
      {/* Desktop & tablet: pinned horizontal sequence */}
      <section ref={section} className="relative hidden md:block" style={{ height: `${CHAPTERS.length * 85 + 60}vh` }} aria-labelledby="exp-title">
        <div className="sticky top-0 h-screen overflow-hidden">
          <div className="absolute left-10 top-28 z-10 transition-opacity duration-300" style={{ opacity: Math.max(0, 1 - progress * 8) }}>
            <p className="eyebrow text-primary">02 — The experience</p>
            <h2 id="exp-title" className="font-display mt-3 text-5xl">Feel the performance</h2>
          </div>
          <div className="font-display text-outline pointer-events-none absolute -bottom-10 left-0 whitespace-nowrap text-[22vw] opacity-[0.18]" style={{ transform: `translateX(${-progress * 30}%)` }} aria-hidden>
            Rhythm · Energy · Presence
          </div>
          <div ref={track} className="flex h-full items-center will-change-transform" style={{ transform: `translate3d(${-progress * distance}px, 0, 0)` }}>
            <div className="w-[36vw] shrink-0" />
            {CHAPTERS.map((c, i) => (
              <ChapterPanel key={c.n} c={c} index={i} progress={progress} />
            ))}
            <div className="w-[10vw] shrink-0" />
          </div>
          <div className="absolute bottom-10 left-10 right-10 z-10 flex items-center gap-4">
            <span className="eyebrow text-muted-foreground">0{Math.min(CHAPTERS.length, Math.floor(progress * CHAPTERS.length) + 1)}</span>
            <div className="h-px flex-1 bg-border">
              <div className="h-px bg-primary" style={{ width: `${progress * 100}%` }} />
            </div>
            <span className="eyebrow text-muted-foreground">0{CHAPTERS.length}</span>
          </div>
        </div>
      </section>

      {/* Mobile: stacked editorial chapters */}
      <section className="px-5 py-24 md:hidden" aria-labelledby="exp-title-m">
        <p className="eyebrow text-primary">02 — The experience</p>
        <h2 id="exp-title-m" className="font-display mt-3 text-6xl">Feel the performance</h2>
        <div className="mt-14 flex flex-col gap-20">
          {CHAPTERS.map((c, i) => (
            <article key={c.n} className="relative">
              <Reveal variant="image" className={cn("relative aspect-[4/5] overflow-hidden", i % 2 ? "ml-10" : "mr-10")}>
                <img src={c.main.src} srcSet={c.main.srcSet} sizes="90vw" alt={c.main.alt} loading="lazy" className="h-full w-full object-cover" />
              </Reveal>
              <Reveal className={cn("absolute -bottom-8 w-[42%] overflow-hidden shadow-deep", i % 2 ? "left-0" : "right-0")}>
                <img src={c.second.src} srcSet={c.second.srcSet} sizes="45vw" alt={c.second.alt} loading="lazy" className="aspect-[3/4] w-full object-cover" />
              </Reveal>
              <Reveal className="mt-14">
                <span className={cn("font-editorial text-4xl", c.tone)}>{c.n}</span>
                <h3 className="font-display text-6xl">{c.title}</h3>
                <p className="mt-3 text-foreground/70">{c.line}</p>
              </Reveal>
            </article>
          ))}
        </div>
      </section>
    </>
  );
}
