import { Link } from "@tanstack/react-router";
import { useRef, useState } from "react";
import { ArrowRight } from "lucide-react";
import { photos, type Photo } from "@/lib/media";
import { useParallax } from "@/hooks/use-motion";
import { Lightbox } from "./Lightbox";
import { Reveal } from "./Reveal";
import { cn } from "@/lib/utils";

export type GalleryItem = Photo & { caption: string };

export const GALLERY: GalleryItem[] = [
  { ...photos.djembe, caption: "Djembe set above the room — Shoko Lounge, Rabat" },
  { ...photos.gnawaNight, caption: "Leading the procession" },
  { ...photos.laser2, caption: "Under the lasers" },
  { ...photos.weddingColor, caption: "“My rhythm, your energy…” — wedding, October 2026" },
  { ...photos.bwJoy, caption: "Dancing with the bride" },
  { ...photos.shokoWide, caption: "Golden hour at Shoko Lounge, Rabat" },
  { ...photos.laser1, caption: "Light and shade" },
  { ...photos.weddingBw, caption: "The bride's moment" },
  { ...photos.gnawaTroupe, caption: "Cymbals and colour" },
  { ...photos.weddingSmile, caption: "All smiles, all rhythm" },
  { ...photos.gardenClose, caption: "Pure joy" },
  { ...photos.laser3, caption: "Glow" },
];

/** Horizontal, drag-to-scroll strip with giant typography behind (home page). */
export function GalleryStrip() {
  const [open, setOpen] = useState<number | null>(null);
  const items = GALLERY.slice(0, 9);
  return (
    <section className="relative overflow-hidden py-28 md:py-40" aria-labelledby="gallery-strip-title">
      <div className="font-display text-outline pointer-events-none absolute left-0 top-1/2 -translate-y-1/2 whitespace-nowrap text-[30vw] opacity-[0.12]" aria-hidden>
        Archive
      </div>
      <div className="relative mx-auto flex max-w-[1600px] items-end justify-between px-5 md:px-10">
        <div>
          <p className="eyebrow text-primary">04 — Visual archive</p>
          <h2 id="gallery-strip-title" className="font-display mt-4 text-6xl md:text-8xl">
            Frames <span className="font-editorial normal-case text-primary">from the floor</span>
          </h2>
        </div>
        <Link to="/gallery" className="eyebrow hidden items-center gap-2 text-foreground/80 hover:text-primary md:flex">
          Full gallery <ArrowRight className="size-4" />
        </Link>
      </div>

      <div className="relative mt-14 flex snap-x snap-mandatory gap-4 overflow-x-auto px-5 pb-6 [scrollbar-width:none] md:gap-6 md:px-10 [&::-webkit-scrollbar]:hidden">
        {items.map((p, i) => (
          <button
            key={p.src}
            type="button"
            onClick={() => setOpen(i)}
            data-cursor="View"
            className={cn(
              "group relative shrink-0 snap-start overflow-hidden text-left",
              p.orientation === "landscape" ? "h-[52vh] w-[78vw] md:h-[62vh] md:w-[44vw]" : "h-[52vh] w-[60vw] md:h-[62vh] md:w-[24vw]",
              i % 2 === 1 && "md:mt-16",
            )}
          >
            <img src={p.src} srcSet={p.srcSet} sizes="(min-width:768px) 44vw, 80vw" alt={p.alt} loading="lazy" className="h-full w-full object-cover transition-transform duration-[1.4s] ease-out group-hover:scale-105" />
            <div className="bg-fade-b absolute inset-0 opacity-0 transition-opacity duration-500 group-hover:opacity-100" />
            <span className="absolute bottom-4 left-4 right-4 text-sm text-foreground/90 opacity-0 transition-opacity duration-500 group-hover:opacity-100">{p.caption}</span>
          </button>
        ))}
        <Link to="/gallery" className="flex h-[52vh] w-[60vw] shrink-0 snap-start flex-col items-center justify-center gap-4 border border-border md:h-[62vh] md:w-[20vw]">
          <span className="font-display text-5xl">See all</span>
          <ArrowRight className="size-6 text-primary" />
        </Link>
      </div>
      <Lightbox items={items} index={open} onClose={() => setOpen(null)} onIndex={setOpen} />
    </section>
  );
}

function ArchiveTile({ item, className, onOpen, depth = 1 }: { item: GalleryItem; className?: string; onOpen: () => void; depth?: number }) {
  const ref = useParallax<HTMLDivElement>();
  return (
    <div ref={ref} className={className}>
      <Reveal variant="image" className="h-full">
        <button type="button" onClick={onOpen} data-cursor="View" className="group relative block h-full w-full overflow-hidden text-left">
          <img
            src={item.src}
            srcSet={item.srcSet}
            sizes="(min-width:768px) 50vw, 100vw"
            alt={item.alt}
            loading="lazy"
            className="h-full w-full object-cover transition-transform duration-[1.4s] ease-out group-hover:scale-[1.04]"
            style={{ translate: `0 calc(var(--parallax, 0) * ${-24 * depth}px)` }}
          />
          <span className="absolute inset-x-0 bottom-0 translate-y-full bg-background/80 px-4 py-3 text-sm backdrop-blur transition-transform duration-500 group-hover:translate-y-0">
            {item.caption}
          </span>
        </button>
      </Reveal>
    </div>
  );
}

/** Art-directed archive with asymmetric composition (gallery page). */
export function GalleryArchive() {
  const [open, setOpen] = useState<number | null>(null);
  const layout = [
    "md:col-span-7 aspect-[4/5] md:aspect-auto md:h-[110vh]",
    "md:col-span-5 md:mt-40 aspect-[5/4]",
    "md:col-span-8 md:col-start-3 aspect-[3/2]",
    "md:col-span-4 aspect-[3/4] md:h-[80vh]",
    "md:col-span-4 md:mt-32 aspect-[3/4] md:h-[80vh]",
    "md:col-span-4 aspect-[5/4] md:mt-64",
    "md:col-span-12 aspect-[3/2]",
    "md:col-span-5 aspect-[3/4] md:h-[90vh]",
    "md:col-span-4 md:col-start-8 md:mt-48 aspect-[3/4] md:h-[80vh]",
    "md:col-span-6 aspect-[3/4] md:h-[100vh]",
    "md:col-span-6 md:mt-28 aspect-[5/4]",
    "md:col-span-4 aspect-[3/4] md:h-[75vh]",
    "md:col-span-4 md:mt-40 aspect-[3/4] md:h-[75vh]",
    "md:col-span-4 aspect-[3/4] md:h-[75vh]",
    "md:col-span-5 md:col-start-2 aspect-[3/4] md:h-[85vh]",
    "md:col-span-5 md:mt-36 aspect-[3/4] md:h-[85vh]",
  ];
  const strip = useRef<HTMLDivElement>(null);
  return (
    <section ref={strip} className="relative px-5 pb-32 md:px-10" aria-label="Photo archive">
      <div className="mx-auto grid max-w-[1600px] grid-cols-1 gap-6 md:grid-cols-12 md:gap-8">
        {GALLERY.map((item, i) => (
          <ArchiveTile key={item.src} item={item} className={cn("relative overflow-hidden", layout[i % layout.length])} onOpen={() => setOpen(i)} depth={(i % 3) + 1} />
        ))}
      </div>
      <Lightbox items={GALLERY} index={open} onClose={() => setOpen(null)} onIndex={setOpen} />
    </section>
  );
}
