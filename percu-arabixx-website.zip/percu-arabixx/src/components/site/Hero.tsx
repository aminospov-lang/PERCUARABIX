import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowDown } from "lucide-react";
import { photos, type Photo } from "@/lib/media";
import { Button } from "@/components/ui/button";
import { Magnetic } from "./Magnetic";
import { cn } from "@/lib/utils";

const PANELS: { photo: Photo; position: string; offset: string }[] = [
  { photo: photos.djembe, position: "50% 40%", offset: "translate-y-[6%]" },
  { photo: photos.gnawaLead, position: "50% 45%", offset: "-translate-y-[4%]" },
  { photo: photos.gardenDrum, position: "45% 40%", offset: "translate-y-[9%]" },
  { photo: photos.bwJoy, position: "60% 40%", offset: "-translate-y-[2%]" },
];

const WORDS = ["Rhythm.", "Energy.", "Presence."];

function SplitWord({ word, base = 0 }: { word: string; base?: number }) {
  return (
    <span className="inline-flex overflow-hidden pb-[0.04em]">
      {word.split("").map((ch, i) => (
        <span key={i} className="hero-letter" style={{ animationDelay: `${base + i * 45}ms` }}>
          {ch}
        </span>
      ))}
    </span>
  );
}

export function Hero() {
  const [word, setWord] = useState(0);

  useEffect(() => {
    const id = setInterval(() => setWord((w) => (w + 1) % WORDS.length), 2200);
    return () => clearInterval(id);
  }, []);

  return (
    <section className="grain relative h-[100svh] min-h-[620px] w-full overflow-hidden bg-background" aria-label="Percu Arabixx">
      {/* Mobile: one full-bleed portrait */}
      <div className="absolute inset-0 overflow-hidden md:hidden">
        <img
          src={photos.djembe.src}
          srcSet={photos.djembe.srcSet}
          sizes="100vw"
          alt={photos.djembe.alt}
          fetchPriority="high"
          className="h-full w-full object-cover"
          style={{ objectPosition: "55% 35%" }}
        />
      </div>

      {/* Desktop: four tall photographs side by side, like stage lights */}
      <div className="absolute inset-0 hidden grid-cols-4 gap-2 px-2 md:grid">
        {PANELS.map((p, i) => (
          <div key={i} className={cn("relative h-[115%] -translate-y-[6%] overflow-hidden", p.offset)}>
            <div className="h-full w-full">
              <img
                src={p.photo.src}
                srcSet={p.photo.srcSet}
                sizes="25vw"
                alt={i === 0 ? p.photo.alt : ""}
                fetchPriority={i < 2 ? "high" : "auto"}
                className="h-full w-full object-cover"
                style={{ objectPosition: p.position }}
              />
            </div>
          </div>
        ))}
      </div>

      {/* Light & shade */}
      <div className="absolute inset-0 bg-background/45" />
      <div className="bg-vignette absolute inset-0" />
      <div className="bg-fade-b absolute inset-x-0 bottom-0 h-[65%]" />

      {/* Content */}
      <div className="relative z-10 mx-auto flex h-full max-w-[1600px] flex-col justify-end px-5 pb-28 md:px-10 md:pb-16">
        <p className="eyebrow mb-6 flex items-center gap-3 text-primary">
          <span className="size-2 animate-pulse-beat rounded-full bg-primary" />
          Live percussion · Morocco
        </p>

        <h1 className="font-display text-[23vw] leading-[0.8] md:text-[15.5vw] xl:text-[14.5rem]">
          <span className="block">
            <SplitWord word="Percu" base={200} />
          </span>
          <span className="block md:pl-[12vw]">
            <SplitWord word="Arabixx" base={420} />
          </span>
        </h1>

        <div className="mt-8 flex flex-col gap-8 md:mt-10 md:flex-row md:items-end md:justify-between">
          <div className="max-w-md">
            <p className="font-editorial h-[1.2em] overflow-hidden text-3xl text-primary md:text-4xl" aria-live="polite">
              <span key={word} className="block animate-in fade-in slide-in-from-bottom-4 duration-700">
                {WORDS[word]}
              </span>
            </p>
            <p className="mt-3 text-base leading-relaxed text-foreground/80 md:text-lg">
              Live percussion that turns a room into a moment — from Moroccan weddings to club nights.
            </p>
          </div>

          <div className="flex flex-col gap-3 sm:flex-row">
            <Magnetic>
              <Button asChild variant="hero" size="xl" className="w-full sm:w-auto">
                <Link to="/book">Book Percu Arabixx</Link>
              </Button>
            </Magnetic>
            <Magnetic>
              <Button asChild variant="ghostLight" size="xl" className="w-full sm:w-auto">
                <Link to="/experience">Explore the experience</Link>
              </Button>
            </Magnetic>
          </div>
        </div>
      </div>

      <div className="eyebrow absolute bottom-6 left-1/2 z-10 hidden -translate-x-1/2 items-center gap-2 text-foreground/60 md:flex">
        <ArrowDown className="size-3 animate-bounce" /> Scroll
      </div>
    </section>
  );
}
