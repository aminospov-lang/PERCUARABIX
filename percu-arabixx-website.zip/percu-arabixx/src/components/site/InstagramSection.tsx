import { Instagram } from "lucide-react";
import { artist, photos } from "@/lib/media";
import { Button } from "@/components/ui/button";
import { Magnetic } from "./Magnetic";
import { Marquee } from "./Marquee";
import { Reveal } from "./Reveal";

const TILES = [
  { p: photos.laser2, cls: "left-[2%] top-[6%] w-[40%] -rotate-6 md:w-[22%]" },
  { p: photos.shokoDrum, cls: "right-[4%] top-[2%] w-[34%] rotate-3 md:right-[8%] md:w-[15%]" },
  { p: photos.weddingColor, cls: "left-[6%] bottom-[4%] w-[48%] rotate-2 md:left-[12%] md:w-[24%]" },
  { p: photos.gnawaTroupe, cls: "right-[2%] bottom-[8%] w-[32%] -rotate-3 md:right-[16%] md:w-[13%]" },
  { p: photos.laser1, cls: "hidden md:block left-[36%] -top-[4%] w-[11%] rotate-6" },
  { p: photos.bwJoy, cls: "hidden md:block right-[34%] bottom-[2%] w-[11%] -rotate-6" },
];

export function InstagramSection() {
  return (
    <section className="relative overflow-hidden py-24 md:py-32" aria-labelledby="ig-title">
      <Marquee
        items={[artist.instagramHandle, "Follow the rhythm", artist.instagramHandle, "Live percussion"]}
        className="border-y border-border py-5"
        itemClassName="font-display text-4xl md:text-6xl"
      />
      <div className="relative mx-auto mt-6 h-[110vw] max-w-[1600px] md:h-[46rem]">
        {TILES.map(({ p, cls }) => (
          <a key={p.src} href={artist.instagramUrl} target="_blank" rel="noreferrer" className={`group absolute overflow-hidden shadow-deep transition-transform duration-700 hover:z-10 hover:scale-105 hover:rotate-0 ${cls}`} data-cursor="Follow">
            <img src={p.src} alt={p.alt} loading="lazy" className="aspect-[3/4] w-full object-cover" />
          </a>
        ))}
        <div className="absolute inset-0 flex flex-col items-center justify-center px-5 text-center">
          <Reveal>
            <p className="eyebrow text-primary">On Instagram · 12K followers</p>
          </Reveal>
          <Reveal delay={100}>
            <h2 id="ig-title" className="font-display mt-4 text-[15vw] md:text-[9vw] xl:text-[9rem]">
              Follow <span className="font-editorial normal-case text-primary">the</span> rhythm
            </h2>
          </Reveal>
          <Reveal delay={200} className="mt-8">
            <Magnetic>
              <Button asChild variant="hero" size="xl">
                <a href={artist.instagramUrl} target="_blank" rel="noreferrer">
                  <Instagram /> Follow on Instagram
                </a>
              </Button>
            </Magnetic>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
