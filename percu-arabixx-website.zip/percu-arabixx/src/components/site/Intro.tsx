import { photos } from "@/lib/media";
import { useParallax } from "@/hooks/use-motion";
import { MaskedLines, Reveal } from "./Reveal";

const QUALITIES = [
  { title: "Live percussion", text: "Djembe and hand drums played in the room, not behind it." },
  { title: "Audience interaction", text: "He moves through the crowd — the guests become part of the beat." },
  { title: "Stage presence", text: "Style, attitude and a smile you notice from the back of the room." },
  { title: "Improvisation", text: "Locks onto the DJ or band and reads the floor in real time." },
  { title: "Energy", text: "Builds the peak moments: entrances, drops, the last song of the night." },
  { title: "Atmosphere", text: "Elevates an event from background music to something people film." },
];

export function Intro({ full = false }: { full?: boolean }) {
  const par = useParallax<HTMLDivElement>();
  return (
    <section className="relative overflow-hidden px-5 py-28 md:px-10 md:py-44" aria-labelledby="intro-title">
      <div className="mx-auto grid max-w-[1600px] gap-16 md:grid-cols-12 md:gap-10">
        <div className="md:col-span-7">
          <Reveal>
            <p className="eyebrow mb-8 text-primary">01 — The artist</p>
          </Reveal>
          <MaskedLines
            as="h2"
            lines={[
              <span id="intro-title" key="a">More than</span>,
              "percussion.",
              <span key="c" className="font-editorial normal-case text-primary">an experience.</span>,
            ]}
            className="font-display text-[17vw] leading-[0.85] md:text-[8.5vw] xl:text-[9rem]"
          />
          <Reveal delay={200} className="mt-12 grid max-w-2xl gap-6 text-lg leading-relaxed text-foreground/75 md:text-xl">
            <p>
              Percu Arabixx is the stage name of percussionist <span className="text-foreground">Larbi Jerkech</span>. He doesn't
              play <em className="font-editorial text-2xl text-foreground">at</em> an event — he plays <em className="font-editorial text-2xl text-foreground">with</em> it.
            </p>
            {full && (
              <p>
                Drum strapped on, he steps into the crowd, rises above the dance floor and answers the DJ beat for beat. Weddings,
                lounges, club nights — the room changes the moment the first hit lands.
              </p>
            )}
          </Reveal>
        </div>

        <div ref={par} className="relative md:col-span-5">
          <Reveal variant="image" className="relative aspect-[3/4] overflow-hidden">
            <img
              src={photos.djembe.src}
              srcSet={photos.djembe.srcSet}
              sizes="(min-width: 768px) 40vw, 100vw"
              alt={photos.djembe.alt}
              loading="lazy"
              className="h-full w-full object-cover"
              style={{ translate: "0 calc(var(--parallax, 0) * -40px)" }}
            />
          </Reveal>
          <p className="eyebrow mt-4 text-muted-foreground">Shoko Lounge · Rabat</p>
          <div className="font-display text-outline pointer-events-none absolute -left-10 -top-14 hidden text-[10rem] opacity-40 md:block" aria-hidden>
            01
          </div>
        </div>
      </div>

      <div className="mx-auto mt-24 grid max-w-[1600px] gap-px overflow-hidden border-y border-border sm:grid-cols-2 lg:grid-cols-3 md:mt-36">
        {QUALITIES.map((q, i) => (
          <Reveal key={q.title} delay={i * 70} className="group relative bg-background p-8 md:p-10">
            <span className="eyebrow text-muted-foreground">0{i + 1}</span>
            <h3 className="font-display mt-6 text-4xl transition-colors duration-500 group-hover:text-primary md:text-5xl">{q.title}</h3>
            <p className="mt-4 max-w-xs text-foreground/65">{q.text}</p>
            <span className="absolute bottom-0 left-0 h-px w-0 bg-primary transition-[width] duration-700 group-hover:w-full" />
          </Reveal>
        ))}
      </div>
    </section>
  );
}
