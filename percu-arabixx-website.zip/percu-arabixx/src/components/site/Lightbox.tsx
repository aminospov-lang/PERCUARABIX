import { useCallback, useEffect } from "react";
import { ChevronLeft, ChevronRight, X } from "lucide-react";
import type { Photo } from "@/lib/media";

export function Lightbox({
  items,
  index,
  onClose,
  onIndex,
}: {
  items: (Photo & { caption?: string })[];
  index: number | null;
  onClose: () => void;
  onIndex: (i: number) => void;
}) {
  const open = index !== null;
  const go = useCallback(
    (d: number) => {
      if (index === null) return;
      onIndex((index + d + items.length) % items.length);
    },
    [index, items.length, onIndex],
  );

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowRight") go(1);
      if (e.key === "ArrowLeft") go(-1);
    };
    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", onKey);
    };
  }, [open, go, onClose]);

  if (index === null) return null;
  const item = items[index];
  if (!item) return null;

  return (
    <div className="fixed inset-0 z-[80] flex flex-col bg-background/95 backdrop-blur-xl animate-in fade-in duration-500" role="dialog" aria-modal="true" aria-label="Photo viewer">
      <div className="flex items-center justify-between px-5 py-5 md:px-10">
        <span className="eyebrow text-muted-foreground">
          {String(index + 1).padStart(2, "0")} / {String(items.length).padStart(2, "0")}
        </span>
        <button type="button" onClick={onClose} className="flex size-11 items-center justify-center rounded-full border border-foreground/20 hover:border-primary hover:text-primary" aria-label="Close">
          <X className="size-5" />
        </button>
      </div>
      <div className="relative flex min-h-0 flex-1 items-center justify-center px-4 md:px-24">
        <img key={item.src} src={item.src} srcSet={item.srcSet} sizes="90vw" alt={item.alt} className="max-h-full max-w-full object-contain animate-in fade-in zoom-in-95 duration-700" />
        <button type="button" onClick={() => go(-1)} className="absolute left-2 top-1/2 flex size-12 -translate-y-1/2 items-center justify-center rounded-full border border-foreground/20 bg-background/40 backdrop-blur md:left-8" aria-label="Previous photo">
          <ChevronLeft className="size-5" />
        </button>
        <button type="button" onClick={() => go(1)} className="absolute right-2 top-1/2 flex size-12 -translate-y-1/2 items-center justify-center rounded-full border border-foreground/20 bg-background/40 backdrop-blur md:right-8" aria-label="Next photo">
          <ChevronRight className="size-5" />
        </button>
      </div>
      <p className="mx-auto max-w-2xl px-5 py-6 text-center text-sm text-foreground/70">{item.caption ?? item.alt}</p>
    </div>
  );
}
