import type { ReactNode } from "react";
import { useMagnetic } from "@/hooks/use-motion";
import { cn } from "@/lib/utils";

export function Magnetic({ children, className, strength = 0.28 }: { children: ReactNode; className?: string; strength?: number }) {
  const ref = useMagnetic<HTMLSpanElement>(strength);
  return (
    <span ref={ref} className={cn("inline-block will-change-transform", className)}>
      {children}
    </span>
  );
}
