import { cn } from "@/lib/utils";

export function Marquee({
  items,
  reverse = false,
  className,
  itemClassName,
}: {
  items: string[];
  reverse?: boolean;
  className?: string;
  itemClassName?: string;
}) {
  const row = [...items, ...items];
  return (
    <div className={cn("relative flex overflow-hidden select-none", className)} aria-hidden>
      <div className={cn("flex shrink-0 items-center gap-10 pr-10", reverse ? "animate-marquee-reverse" : "animate-marquee")}>
        {row.map((t, i) => (
          <span key={i} className={cn("flex items-center gap-10 whitespace-nowrap", itemClassName)}>
            {t}
            <span className="inline-block size-2 rounded-full bg-primary" />
          </span>
        ))}
      </div>
    </div>
  );
}
