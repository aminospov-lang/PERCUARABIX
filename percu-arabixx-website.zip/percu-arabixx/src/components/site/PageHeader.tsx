import type { ReactNode } from "react";
import type { Photo } from "@/lib/media";
import { MaskedLines, Reveal } from "./Reveal";

export function PageHeader({ eyebrow, title, accent, intro, image }: { eyebrow: string; title: string; accent?: string; intro?: ReactNode; image: Photo }) {
  return (
    <section className="grain relative flex min-h-[78svh] items-end overflow-hidden">
      <img src={image.src} srcSet={image.srcSet} sizes="100vw" alt="" fetchPriority="high" className="absolute inset-0 h-full w-full animate-ken-burns object-cover" />
      <div className="absolute inset-0 bg-background/55" />
      <div className="bg-fade-b absolute inset-x-0 bottom-0 h-3/4" />
      <div className="relative mx-auto w-full max-w-[1600px] px-5 pb-14 pt-40 md:px-10 md:pb-20">
        <Reveal>
          <p className="eyebrow text-primary">{eyebrow}</p>
        </Reveal>
        <MaskedLines
          as="h1"
          lines={[title, ...(accent ? [<span key="acc" className="font-editorial normal-case text-primary">{accent}</span>] : [])]}
          className="font-display mt-5 text-[18vw] leading-[0.84] md:text-[11vw] xl:text-[11rem]"
        />
        {intro && (
          <Reveal delay={250} className="mt-8 max-w-xl text-lg text-foreground/75">
            {intro}
          </Reveal>
        )}
      </div>
    </section>
  );
}
