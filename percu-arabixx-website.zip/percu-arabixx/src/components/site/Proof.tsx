import { useEffect, useState } from "react";
import { ArrowUpRight } from "lucide-react";
import { artist, quotes } from "@/lib/media";
import { Reveal } from "./Reveal";
import { cn } from "@/lib/utils";

/** The artist's own words, with a changing backdrop. No invented testimonials. */
export function Voices() {
  const [i, setI] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setI((v) => (v + 1) % quotes.length), 6500);
    return () => clearInterval(id);
  }, []);

  return (
    <section className="relative flex min-h-[90svh] items-center overflow-hidden" aria-label="In his words">
      {quotes.map((q, idx) => (
        <img
          key={q.text}
          src={q.image.src}
          srcSet={q.image.srcSet}
          sizes="100vw"
          alt=""
          loading="lazy"
          className={cn("absolute inset-0 h-full w-full object-cover transition-[opacity,transform] duration-[2s]", idx === i ? "scale-100 opacity-100" : "scale-110 opacity-0")}
        />
      ))}
      <div className="absolute inset-0 bg-background/65" />
      <div className="bg-vignette absolute inset-0" />

      <div className="relative mx-auto w-full max-w-[1400px] px-5 py-24 md:px-10">
        <p className="eyebrow text-primary">In his words</p>
        <div className="relative mt-8 min-h-[14rem] md:min-h-[18rem]">
          {quotes.map((q, idx) => (
            <blockquote
              key={q.text}
              className={cn("absolute inset-0 transition-[opacity,transform] duration-1000", idx === i ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-6 opacity-0")}
              aria-hidden={idx !== i}
            >
              <p className="font-editorial text-4xl leading-[1.1] md:text-7xl">“{q.text}”</p>
              <footer className="eyebrow mt-8 text-foreground/60">
                @percu.arabixx · {q.context}
              </footer>
            </blockquote>
          ))}
        </div>
        <div className="mt-10 flex gap-2">
          {quotes.map((q, idx) => (
            <button key={q.text} type="button" onClick={() => setI(idx)} className={cn("h-1 rounded-full transition-[width,background-color] duration-500", idx === i ? "w-12 bg-primary" : "w-6 bg-foreground/30")} aria-label={`Show quote ${idx + 1}`} />
          ))}
        </div>
      </div>
    </section>
  );
}

/** Venues & collaborations taken only from the artist's public Instagram. */
export function Venues() {
  return (
    <section className="px-5 py-28 md:px-10 md:py-40" aria-labelledby="venues-title">
      <div className="mx-auto max-w-[1600px]">
        <div className="grid gap-10 md:grid-cols-12">
          <div className="md:col-span-4">
            <p className="eyebrow text-primary">Selected venues & collaborations</p>
            <h2 id="venues-title" className="font-display mt-4 text-6xl md:text-7xl">Heard at</h2>
            <p className="mt-6 max-w-xs text-sm text-muted-foreground">As listed on the artist's Instagram profile and posts.</p>
          </div>
          <div className="md:col-span-8">
            {artist.venues.map((v, i) => (
              <Reveal key={v.handle} delay={i * 80}>
                <a href={v.url} target="_blank" rel="noreferrer" className="group flex items-baseline justify-between gap-4 border-t border-border py-6">
                  <span className="font-display text-5xl transition-colors duration-500 group-hover:text-primary md:text-7xl">{v.name}</span>
                  <span className="eyebrow flex shrink-0 items-center gap-2 text-muted-foreground">
                    <span className="hidden sm:inline">{v.city}</span>
                    <ArrowUpRight className="size-4 transition-transform duration-500 group-hover:rotate-45 group-hover:text-primary" />
                  </span>
                </a>
              </Reveal>
            ))}
            <div className="grid gap-px border-t border-border sm:grid-cols-2">
              {artist.collaborations.map((c) => (
                <a key={c.handle} href={c.url} target="_blank" rel="noreferrer" className="group py-6 sm:pr-6">
                  <p className="eyebrow text-muted-foreground">Collaboration</p>
                  <p className="font-display mt-2 text-3xl normal-case transition-colors group-hover:text-primary">{c.handle}</p>
                  <p className="mt-1 text-sm text-foreground/60">{c.note}</p>
                </a>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
