import type { CSSProperties, ElementType, ReactNode } from "react";
import { cn } from "@/lib/utils";
import { useReveal } from "@/hooks/use-motion";

type Variant = "fade" | "mask" | "image" | "lines";

const variantClass: Record<Variant, string> = {
  fade: "reveal",
  mask: "reveal-mask",
  image: "reveal-image",
  lines: "mask-group",
};

export function Reveal({
  as: Tag = "div",
  variant = "fade",
  delay = 0,
  className,
  style,
  children,
}: {
  as?: ElementType;
  variant?: Variant;
  delay?: number;
  className?: string;
  style?: CSSProperties;
  children: ReactNode;
}) {
  const ref = useReveal<HTMLElement>();
  return (
    <Tag
      ref={ref}
      className={cn(variantClass[variant], className)}
      style={{ transitionDelay: delay ? `${delay}ms` : undefined, ...style }}
    >
      {children}
    </Tag>
  );
}

/** Headline revealed line by line through a mask. */
export function MaskedLines({
  lines,
  className,
  lineClassName,
  as: Tag = "h2",
  stagger = 110,
}: {
  lines: ReactNode[];
  className?: string;
  lineClassName?: string;
  as?: ElementType;
  stagger?: number;
}) {
  const ref = useReveal<HTMLElement>();
  return (
    <Tag ref={ref} className={cn("mask-group", className)}>
      {lines.map((line, i) => (
        <span key={i} className={cn("mask-line", lineClassName)}>
          <span style={{ transitionDelay: `${i * stagger}ms` }}>{line}</span>
        </span>
      ))}
    </Tag>
  );
}
