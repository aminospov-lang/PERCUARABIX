import { Link, useRouterState } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Instagram, MessageCircle, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { artist } from "@/lib/media";
import { Magnetic } from "./Magnetic";

const NAV = [
  { to: "/", label: "Home" },
  { to: "/experience", label: "Experience" },
  { to: "/events", label: "Events" },
  { to: "/gallery", label: "Gallery" },
  { to: "/about", label: "About" },
  { to: "/book", label: "Book" },
] as const;

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <>
      <header
        className={cn(
          "fixed inset-x-0 top-0 z-50 transition-[background-color,backdrop-filter,padding] duration-500",
          scrolled ? "bg-background/70 py-3 backdrop-blur-xl" : "py-5 md:py-7",
        )}
      >
        <div className="mx-auto flex max-w-[1600px] items-center justify-between px-5 md:px-10">
          <Link to="/" className="group flex items-baseline gap-2" aria-label="Percu Arabixx — home">
            <span className="font-display text-2xl tracking-wide md:text-[1.7rem]">
              Percu<span className="text-primary">·</span>Arabixx
            </span>
          </Link>

          <nav className="hidden items-center gap-8 lg:flex" aria-label="Main">
            {NAV.slice(0, 5).map((item) => (
              <Link
                key={item.to}
                to={item.to}
                className="eyebrow relative text-foreground/70 transition-colors hover:text-foreground"
                activeProps={{ className: "!text-primary" }}
                activeOptions={{ exact: true }}
              >
                {item.label}
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-3">
            <Magnetic className="hidden md:inline-block">
              <Link
                to="/book"
                className="eyebrow inline-flex h-11 items-center gap-2 rounded-full bg-primary px-6 text-primary-foreground transition-shadow duration-500 hover:shadow-glow"
              >
                <span className="size-1.5 animate-pulse-beat rounded-full bg-primary-foreground" />
                Book now
              </Link>
            </Magnetic>
            <button
              type="button"
              onClick={() => setOpen(true)}
              className="flex h-11 items-center gap-3 rounded-full border border-foreground/20 px-4 lg:hidden"
              aria-label="Open menu"
              aria-expanded={open}
            >
              <span className="eyebrow">Menu</span>
              <span className="flex flex-col gap-1">
                <span className="block h-px w-5 bg-foreground" />
                <span className="block h-px w-3 self-end bg-foreground" />
              </span>
            </button>
          </div>
        </div>
      </header>

      {/* Mobile full-screen menu */}
      <div
        className={cn(
          "fixed inset-0 z-[60] flex flex-col bg-background transition-[clip-path] duration-700 lg:hidden",
          open ? "[clip-path:circle(150%_at_100%_0)]" : "pointer-events-none [clip-path:circle(0%_at_100%_0)]",
        )}
        aria-hidden={!open}
      >
        <div className="bg-stage-glow absolute inset-0 opacity-70" />
        <div className="relative flex items-center justify-between px-5 py-5">
          <span className="font-display text-2xl">
            Percu<span className="text-primary">·</span>Arabixx
          </span>
          <button
            type="button"
            onClick={() => setOpen(false)}
            className="flex size-11 items-center justify-center rounded-full border border-foreground/20"
            aria-label="Close menu"
          >
            <X className="size-5" />
          </button>
        </div>
        <nav className="relative flex flex-1 flex-col justify-center gap-1 px-5" aria-label="Mobile">
          {NAV.map((item, i) => (
            <Link
              key={item.to}
              to={item.to}
              className="group flex items-baseline gap-4 py-1"
              style={{
                transition: "opacity .6s, transform .8s cubic-bezier(.22,1,.36,1)",
                transitionDelay: open ? `${150 + i * 60}ms` : "0ms",
                opacity: open ? 1 : 0,
                transform: open ? "none" : "translateY(30px)",
              }}
            >
              <span className="eyebrow w-6 text-muted-foreground">0{i + 1}</span>
              <span className="font-display text-[15vw] leading-[0.95] transition-colors group-hover:text-primary sm:text-7xl">
                {item.label}
              </span>
            </Link>
          ))}
        </nav>
        <div className="relative flex items-center justify-between gap-3 border-t border-border px-5 py-6">
          <a href={artist.instagramUrl} target="_blank" rel="noreferrer" className="eyebrow flex items-center gap-2 text-muted-foreground">
            <Instagram className="size-4" /> {artist.instagramHandle}
          </a>
          <a href={artist.whatsappUrl} target="_blank" rel="noreferrer" className="eyebrow flex items-center gap-2 text-primary">
            <MessageCircle className="size-4" /> WhatsApp
          </a>
        </div>
      </div>
    </>
  );
}

/** Sticky Book Now — bottom bar on mobile, floating pill on desktop. Hidden on the booking & admin pages. */
export function FloatingBook() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [show, setShow] = useState(false);

  useEffect(() => {
    const onScroll = () =>
      setShow(window.scrollY > window.innerHeight * 0.6 && window.scrollY + window.innerHeight < document.documentElement.scrollHeight - 520);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  if (pathname.startsWith("/book") || pathname.startsWith("/admin") || pathname.startsWith("/auth") || pathname.startsWith("/reset")) return null;

  return (
    <div
      className={cn(
        "fixed z-40 transition-[opacity,transform] duration-500",
        "inset-x-3 bottom-3 md:inset-x-auto md:bottom-8 md:right-8",
        show ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-6 opacity-0",
      )}
    >
      <div className="flex gap-2">
        <a
          href={artist.whatsappUrl}
          target="_blank"
          rel="noreferrer"
          aria-label="Message on WhatsApp"
          className="flex h-14 w-14 shrink-0 items-center justify-center rounded-full border border-foreground/20 bg-background/80 backdrop-blur-xl md:hidden"
        >
          <MessageCircle className="size-5 text-primary" />
        </a>
        <Link
          to="/book"
          className="eyebrow flex h-14 flex-1 items-center justify-center gap-3 rounded-full bg-primary px-8 text-primary-foreground shadow-deep transition-shadow duration-500 hover:shadow-glow"
        >
          <span className="size-2 animate-pulse-beat rounded-full bg-primary-foreground" />
          Book Percu Arabixx
        </Link>
      </div>
    </div>
  );
}
