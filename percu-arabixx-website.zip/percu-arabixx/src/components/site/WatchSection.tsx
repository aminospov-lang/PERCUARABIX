import { ArrowUpRight, Instagram } from "lucide-react";
import { photos, reelLinks, type Photo } from "@/lib/media";
import { useParallax } from "@/hooks/use-motion";
import { Reveal } from "./Reveal";
import { cn } from "@/lib/utils";

function Still({ photo, className, depth = 1, position }: { photo: Photo; className?: string; depth?: number; position?: string }) {
  const ref = useParallax<HTMLDivElement>();
  return (
    <div ref={ref} className={className}>
      <Reveal variant="image" className="h-full overflow-hidden">
        <img
          src={photo.src}
          srcSet={photo.srcSet}
          sizes="(min-width:768px) 50vw, 100vw"
          alt={photo.alt}
          loading="lazy"
          className="h-full w-full object-cover"
          style={{ translate: `0 calc(var(--parallax, 0) * ${-30 * depth}px)`, objectPosition: position }}
        />
      </Reveal>
    </div>
  );
}

/** Performance moments — high-resolution photography, with the reels linked out to Instagram. */
export function WatchSection() {
  return (
    <section className="bg-stage-glow relative overflow-hidden py-28 md:py-40" aria-labelledby="moments-title">
      <div className="mx-auto max-w-[1600px] px-5 md:px-10">
        <Reveal>
          <p className="eyebrow text-primary">05 — Performance moments</p>
        </Reveal>
        <Reveal delay={100}>
          <h2 id="moments-title" className="font-display mt-4 text-[17vw] md:text-[10vw] xl:text-[11rem]">
            Inside the <span className="text-outline-primary">performance</span>
          </h2>
        </Reveal>
      </div>

      {/* Full-bleed feature */}
      <div className="relative mt-16 md:mt-24">
        <Still photo={photos.gnawaNight} className="h-[70svh] w-full md:h-[92vh]" depth={1.5} />
        <div className="bg-fade-b pointer-events-none absolute inset-x-0 bottom-0 h-1/2" />
        <p className="font-editorial absolute bottom-8 left-5 max-w-xl text-3xl md:bottom-14 md:left-10 md:text-5xl">
          Leading the procession, drum first.
        </p>
      </div>

      {/* Staggered trio */}
      <div className="mx-auto mt-6 grid max-w-[1600px] gap-6 px-5 md:mt-10 md:grid-cols-12 md:gap-8 md:px-10">
        <Still photo={photos.weddingSmile} className="aspect-[4/5] md:col-span-5 md:aspect-auto md:h-[78vh]" position="78% 40%" />
        <div className="flex flex-col gap-6 md:col-span-7 md:mt-40 md:gap-8">
          <Still photo={photos.weddingBw} className="aspect-[3/2]" depth={2} />
          <Still photo={photos.laser3} className="aspect-[3/2] md:ml-auto md:w-[70%]" depth={0.8} />
        </div>
      </div>

      {/* Reels on Instagram */}
      <div className="mx-auto mt-24 max-w-[1600px] px-5 md:mt-36 md:px-10">
        <div className="flex flex-col justify-between gap-4 md:flex-row md:items-end">
          <h3 className="font-display text-5xl md:text-7xl">Watch the reels</h3>
          <p className="eyebrow flex items-center gap-2 text-muted-foreground">
            <Instagram className="size-4" /> On @percu.arabixx
          </p>
        </div>
        <div className="mt-10">
          {reelLinks.map((r, i) => (
            <Reveal key={r.url} delay={i * 60}>
              <a
                href={r.url}
                target="_blank"
                rel="noreferrer"
                data-cursor="Watch"
                className="group grid grid-cols-12 items-baseline gap-4 border-t border-border py-6 last:border-b md:py-8"
              >
                <span className="eyebrow col-span-2 text-muted-foreground md:col-span-1">0{i + 1}</span>
                <span className={cn("font-display col-span-10 text-3xl transition-[color,transform] duration-500 group-hover:translate-x-3 group-hover:text-primary md:col-span-7 md:text-5xl")}>
                  {r.title}
                </span>
                <span className="eyebrow col-span-10 col-start-3 text-muted-foreground md:col-span-3 md:col-start-auto">{r.setting}</span>
                <ArrowUpRight className="col-span-1 hidden size-7 justify-self-end text-primary transition-transform duration-500 group-hover:rotate-45 md:block" />
              </a>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
