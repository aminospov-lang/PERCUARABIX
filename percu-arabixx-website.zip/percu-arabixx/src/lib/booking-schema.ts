import { z } from "zod";

export const EVENT_TYPES = [
  { value: "private_event", label: "Private Event" },
  { value: "wedding", label: "Wedding" },
  { value: "corporate_event", label: "Corporate Event" },
  { value: "club", label: "Club" },
  { value: "festival", label: "Festival" },
  { value: "brand_activation", label: "Brand Activation" },
  { value: "concert", label: "Concert" },
  { value: "other", label: "Other" },
] as const;

export type EventTypeValue = (typeof EVENT_TYPES)[number]["value"];

export const EVENT_TYPE_VALUES = EVENT_TYPES.map((e) => e.value) as [EventTypeValue, ...EventTypeValue[]];

export const eventTypeLabel = (value: string) =>
  EVENT_TYPES.find((e) => e.value === value)?.label ?? value;

export const DURATIONS = ["30 minutes", "1 hour", "2 hours", "3 hours", "4 hours or more", "Not sure yet"] as const;

export const BUDGETS = [
  "Under 5,000 MAD",
  "5,000 – 10,000 MAD",
  "10,000 – 20,000 MAD",
  "20,000 – 40,000 MAD",
  "40,000+ MAD",
  "Let's discuss",
] as const;

export const DISCOVERY_SOURCES = [
  "Instagram",
  "Saw a live performance",
  "Friend or word of mouth",
  "Event planner / agency",
  "Venue recommendation",
  "Google",
  "Other",
] as const;

export const BOOKING_STATUSES = [
  { value: "new", label: "New" },
  { value: "contacted", label: "Contacted" },
  { value: "confirmed", label: "Confirmed" },
  { value: "declined", label: "Declined" },
  { value: "completed", label: "Completed" },
] as const;

export type BookingStatus = (typeof BOOKING_STATUSES)[number]["value"];

/** Minimum time (ms) a human needs to fill the form; faster submissions are treated as bots. */
export const MIN_FILL_TIME_MS = 4000;
/** Maximum booking requests accepted from the same email address per hour. */
export const MAX_REQUESTS_PER_EMAIL_PER_HOUR = 3;

const todayISO = (now: Date) => {
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, "0");
  const d = String(now.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
};

const optionalText = (max: number) =>
  z
    .string()
    .trim()
    .max(max)
    .optional()
    .transform((v) => (v ? v : undefined));

export const makeBookingSchema = (now: Date = new Date()) =>
  z.object({
    full_name: z.string().trim().min(2, "Please enter your full name").max(120),
    email: z.string().trim().toLowerCase().email("Please enter a valid email").max(200),
    phone: z
      .string()
      .trim()
      .min(6, "Please enter a phone or WhatsApp number")
      .max(30)
      .regex(/^[+()\d\s.-]+$/, "Use digits, spaces and + only"),
    company: optionalText(120),
    event_type: z.enum(EVENT_TYPE_VALUES, { errorMap: () => ({ message: "Choose an event type" }) }),
    event_date: z
      .string()
      .regex(/^\d{4}-\d{2}-\d{2}$/, "Choose your event date")
      .refine((d) => d >= todayISO(now), "The event date must be today or later"),
    event_location: z.string().trim().min(2, "Where is the event?").max(200),
    guest_count: z.coerce
      .number()
      .int("Whole number only")
      .min(1, "At least 1 guest")
      .max(100000)
      .optional()
      .or(z.literal("").transform(() => undefined)),
    duration: z.enum(DURATIONS).optional(),
    budget_range: z.enum(BUDGETS).optional(),
    message: optionalText(2000),
    discovery_source: z.enum(DISCOVERY_SOURCES).optional(),
    // Anti-spam fields
    website: z.string().max(200).optional(),
    started_at: z.number().int().positive(),
  });

export type BookingInput = z.input<ReturnType<typeof makeBookingSchema>>;
export type BookingData = z.output<ReturnType<typeof makeBookingSchema>>;

/** True when the submission looks automated: honeypot filled or form filled impossibly fast. */
export function isLikelySpam(input: { website?: string | undefined; started_at: number }, nowMs: number = Date.now()) {
  if (input.website && input.website.trim().length > 0) return true;
  if (nowMs - input.started_at < MIN_FILL_TIME_MS) return true;
  return false;
}
