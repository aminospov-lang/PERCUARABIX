import { createServerFn } from "@tanstack/react-start";
import {
  isLikelySpam,
  makeBookingSchema,
  MAX_REQUESTS_PER_EMAIL_PER_HOUR,
} from "./booking-schema";

export type SubmitBookingResult = { ok: true } | { ok: false; error: string };

export const submitBooking = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => makeBookingSchema(new Date()).parse(input))
  .handler(async ({ data }): Promise<SubmitBookingResult> => {
    // Bots get a silent "success" so they don't retry.
    if (isLikelySpam({ website: data.website, started_at: data.started_at })) {
      return { ok: true };
    }

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const since = new Date(Date.now() - 60 * 60 * 1000).toISOString();
    const { count, error: countError } = await supabaseAdmin
      .from("bookings")
      .select("id", { count: "exact", head: true })
      .eq("email", data.email)
      .gte("created_at", since);

    if (countError) {
      console.error("booking rate-limit check failed", countError);
      return { ok: false, error: "We couldn't send your request right now. Please try again or message us on WhatsApp." };
    }
    if ((count ?? 0) >= MAX_REQUESTS_PER_EMAIL_PER_HOUR) {
      return {
        ok: false,
        error: "We've already received several requests from this email. The team will reply shortly — or reach out on WhatsApp.",
      };
    }

    const { error } = await supabaseAdmin.from("bookings").insert({
      full_name: data.full_name,
      email: data.email,
      phone: data.phone,
      company: data.company ?? null,
      event_type: data.event_type,
      event_date: data.event_date,
      event_location: data.event_location,
      guest_count: typeof data.guest_count === "number" ? data.guest_count : null,
      duration: data.duration ?? null,
      budget_range: data.budget_range ?? null,
      message: data.message ?? null,
      discovery_source: data.discovery_source ?? null,
    });

    if (error) {
      console.error("booking insert failed", error);
      return { ok: false, error: "We couldn't send your request right now. Please try again or message us on WhatsApp." };
    }

    return { ok: true };
  });
