// All photography below comes from the artist's own Instagram account
// (@percu.arabixx). Captions quoted are the artist's own words from those posts.
import djembe800 from "@/assets/media/djembe-shoko-800.webp.asset.json";
import djembe1600 from "@/assets/media/djembe-shoko-1600.webp.asset.json";
import weddingColor900 from "@/assets/media/wedding-color-900.webp.asset.json";
import weddingColor1800 from "@/assets/media/wedding-color-1800.webp.asset.json";
import weddingBw900 from "@/assets/media/wedding-bw-900.webp.asset.json";
import weddingBw1800 from "@/assets/media/wedding-bw-1800.webp.asset.json";
import laser1s from "@/assets/media/laser-1-720.webp.asset.json";
import laser1l from "@/assets/media/laser-1-1440.webp.asset.json";
import laser2s from "@/assets/media/laser-2-720.webp.asset.json";
import laser2l from "@/assets/media/laser-2-1440.webp.asset.json";
import laser3s from "@/assets/media/laser-3-720.webp.asset.json";
import laser3l from "@/assets/media/laser-3-1440.webp.asset.json";

import weddingSmile900 from "@/assets/media/wedding-smile-900.webp.asset.json";
import weddingSmile1800 from "@/assets/media/wedding-smile-1800.webp.asset.json";
import gnawaNight900 from "@/assets/media/gnawa-night-900.webp.asset.json";
import gnawaNight1800 from "@/assets/media/gnawa-night-1800.webp.asset.json";
import shokoWide900 from "@/assets/media/shoko-wide-900.webp.asset.json";
import shokoWide1600 from "@/assets/media/shoko-wide-1600.webp.asset.json";
import shokoDrum900 from "@/assets/media/shoko-drum-900.webp.asset.json";
import shokoDrum1600 from "@/assets/media/shoko-drum-1600.webp.asset.json";
import gnawaLead900 from "@/assets/media/gnawa-lead-900.webp.asset.json";
import gnawaLead1600 from "@/assets/media/gnawa-lead-1600.webp.asset.json";
import gnawaTroupe900 from "@/assets/media/gnawa-troupe-900.webp.asset.json";
import gnawaTroupe1600 from "@/assets/media/gnawa-troupe-1600.webp.asset.json";
import gnawaGuests900 from "@/assets/media/gnawa-guests-900.webp.asset.json";
import gnawaGuests1600 from "@/assets/media/gnawa-guests-1600.webp.asset.json";
import gardenDrum900 from "@/assets/media/garden-drum-900.webp.asset.json";
import gardenDrum1600 from "@/assets/media/garden-drum-1600.webp.asset.json";
import gardenClose900 from "@/assets/media/garden-close-900.webp.asset.json";
import gardenClose1600 from "@/assets/media/garden-close-1600.webp.asset.json";
import bwJoy900 from "@/assets/media/bw-joy-900.webp.asset.json";
import bwJoy1600 from "@/assets/media/bw-joy-1600.webp.asset.json";

export type Photo = {
  src: string;
  srcSet?: string;
  alt: string;
  orientation: "portrait" | "landscape";
};

const hq = (small: { url: string }, large: { url: string }, largeW: number, alt: string, orientation: Photo["orientation"]): Photo => ({
  src: large.url,
  srcSet: `${small.url} 900w, ${large.url} ${largeW}w`,
  alt,
  orientation,
});

export const photos = {
  djembe: {
    src: djembe1600.url,
    srcSet: `${djembe800.url} 800w, ${djembe1600.url} 1600w`,
    alt: "Percu Arabixx playing a djembe on a raised platform above the crowd at Shoko Lounge Rabat, warm amber light",
    orientation: "portrait",
  } as Photo,
  weddingColor: {
    src: weddingColor1800.url,
    srcSet: `${weddingColor900.url} 900w, ${weddingColor1800.url} 1800w`,
    alt: "Percu Arabixx in a sequined jacket and white fedora drumming among wedding guests, with a violinist and pink smoke",
    orientation: "landscape",
  } as Photo,
  weddingBw: {
    src: weddingBw1800.url,
    srcSet: `${weddingBw900.url} 900w, ${weddingBw1800.url} 1800w`,
    alt: "Black and white photo of a bride surrounded by guests and musicians as the percussion builds",
    orientation: "landscape",
  } as Photo,
  weddingSmile: {
    src: weddingSmile1800.url,
    srcSet: `${weddingSmile900.url} 900w, ${weddingSmile1800.url} 1800w`,
    alt: "Black and white photo of Percu Arabixx laughing in a white fedora as he drums beside the bride",
    orientation: "landscape",
  } as Photo,
  gnawaNight: {
    src: gnawaNight1800.url,
    srcSet: `${gnawaNight900.url} 900w, ${gnawaNight1800.url} 1800w`,
    alt: "Percu Arabixx in a sequined jacket leading a procession of performers in traditional dress through a packed, blue-lit wedding hall",
    orientation: "landscape",
  } as Photo,
  laser1: {
    src: laser1l.url,
    srcSet: `${laser1s.url} 720w, ${laser1l.url} 1440w`,
    alt: "Percu Arabixx in profile wearing reflective shades under violet laser beams",
    orientation: "landscape",
  } as Photo,
  laser2: {
    src: laser2l.url,
    srcSet: `${laser2s.url} 720w, ${laser2l.url} 1440w`,
    alt: "Percu Arabixx smiling under a single violet laser beam in a dark club",
    orientation: "landscape",
  } as Photo,
  laser3: {
    src: laser3l.url,
    srcSet: `${laser3s.url} 720w, ${laser3l.url} 1440w`,
    alt: "Close profile of Percu Arabixx with light flaring off his shades",
    orientation: "landscape",
  } as Photo,
  shokoWide: hq(shokoWide900, shokoWide1600, 1600, "Percu Arabixx drumming on a raised platform beneath golden pendant lights at Shoko Lounge Rabat", "landscape"),
  shokoDrum: hq(shokoDrum900, shokoDrum1600, 1600, "Close view of Percu Arabixx's hands on a patterned djembe in warm amber light at Shoko Lounge Rabat", "portrait"),
  gnawaLead: hq(gnawaLead900, gnawaLead1600, 1600, "Percu Arabixx in a white fedora and sequined jacket leading performers in traditional dress through a blue-lit wedding hall", "portrait"),
  gnawaTroupe: hq(gnawaTroupe900, gnawaTroupe1600, 1600, "Performers in blue and gold traditional costume playing metal cymbals among wedding guests", "portrait"),
  gnawaGuests: hq(gnawaGuests900, gnawaGuests1600, 1600, "Wedding guests filming and celebrating as the procession passes under blue light", "portrait"),
  gardenDrum: hq(gardenDrum900, gardenDrum1600, 1600, "Percu Arabixx smiling as he drums beside a violinist at an outdoor wedding, pink smoke behind", "portrait"),
  gardenClose: hq(gardenClose900, gardenClose1600, 1229, "Close portrait of Percu Arabixx laughing under a white fedora, drum in hand", "portrait"),
  bwJoy: hq(bwJoy900, bwJoy1600, 1600, "Black and white photo of Percu Arabixx dancing with his drum beside the bride, guests cheering", "portrait"),
} satisfies Record<string, Photo>;

/** Instagram reels, linked out rather than embedded. */
export const reelLinks = [
  { title: "When the drum meets the room", setting: "Shoko Lounge · Rabat", url: "https://www.instagram.com/percu.arabixx/reel/DdZYjhUBx7Q/" },
  { title: "One rhythm, endless energy", setting: "Wedding · Morocco", url: "https://www.instagram.com/percu.arabixx/reel/Deehmnrt4FF/" },
  { title: "Egyptian warmth, Moroccan elegance", setting: "Wedding celebration", url: "https://www.instagram.com/percu.arabixx/reel/Ddre46NApfw/" },
  { title: "Un mariage pas comme les autres", setting: "Wedding · Morocco", url: "https://www.instagram.com/percu.arabixx/reel/DdE-FukAm82/" },
  { title: "Same passion, every time", setting: "Club night · with @thebigkidd_", url: "https://www.instagram.com/percu.arabixx/reel/Dd4d5q8gt0P/" },
];

/** Verified facts from the public Instagram profile — do not add unverified claims here. */
export const artist = {
  name: "Percu Arabixx",
  realName: "Larbi Jerkech",
  role: "Percussionist",
  instagramHandle: "@percu.arabixx",
  instagramUrl: "https://www.instagram.com/percu.arabixx/",
  // Number published by the artist in his Instagram captions.
  phoneDisplay: "+212 6 40 02 94 04",
  whatsappUrl: "https://wa.me/212640029404?text=" + encodeURIComponent("Hello Percu Arabixx, I'd like to book you for an event."),
  // No public email address was found. Set one here to show it on the site.
  email: null as string | null,
  // Venues listed in the artist's Instagram bio.
  venues: [
    { name: "Shoko Lounge", city: "Rabat", handle: "@shoko_lounge_rabat", url: "https://www.instagram.com/shoko_lounge_rabat/" },
    { name: "Red House", city: "Rabat", handle: "@redhouserabat", url: "https://www.instagram.com/redhouserabat/" },
    { name: "El Cielo", city: "Rabat", handle: "@elcielo_rabat", url: "https://www.instagram.com/elcielo_rabat/" },
    { name: "Baiana Lounge", city: "Rabat", handle: "@baiana_lounge_rabat", url: "https://www.instagram.com/baiana_lounge_rabat/" },
  ],
  // Collaborations named by the artist in his own posts.
  collaborations: [
    { handle: "@thebigkidd_", note: "Four collaborations and counting", url: "https://www.instagram.com/thebigkidd_/" },
    { handle: "@dj_hamza_officiel", note: "Shared performance reel", url: "https://www.instagram.com/dj_hamza_officiel/" },
  ],
  bioFlags: ["🇲🇦", "🇧🇷", "🇶🇦", "🇦🇪"],
};

/** The artist's own words, quoted from his Instagram captions. */
export const quotes = [
  { text: "My rhythm, your energy… together we make this wedding unforgettable.", image: photos.weddingColor, context: "Wedding · October 2026" },
  { text: "When the beat of the drum meets the passion of hearts, unforgettable moments are born.", image: photos.shokoWide, context: "Shoko Lounge Rabat · September 2026" },
  { text: "Your presence is what truly makes the magic complete.", image: photos.laser1, context: "With @thebigkidd_ · September 2026" },
];
