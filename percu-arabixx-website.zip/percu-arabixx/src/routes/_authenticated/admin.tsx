import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useMemo, useState, type ReactNode } from "react";
import { format, parseISO } from "date-fns";
import { Download, Inbox, Loader2, LogOut, Mail, MessageCircle, RefreshCw, Search } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { BOOKING_STATUSES, EVENT_TYPES, eventTypeLabel, type BookingStatus } from "@/lib/booking-schema";
import { cn } from "@/lib/utils";

type Booking = Database["public"]["Tables"]["bookings"]["Row"];

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({
    meta: [
      { title: "Booking requests — Percu Arabixx admin" },
      { name: "description", content: "Private dashboard for Percu Arabixx booking requests." },
      { property: "og:title", content: "Booking requests — Percu Arabixx admin" },
      { property: "og:description", content: "Private dashboard for Percu Arabixx booking requests." },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: AdminPage,
});

const statusTone: Record<BookingStatus, string> = {
  new: "bg-primary text-primary-foreground",
  contacted: "bg-secondary text-foreground",
  confirmed: "bg-success text-primary-foreground",
  declined: "bg-destructive/80 text-destructive-foreground",
  completed: "bg-muted text-muted-foreground",
};

function StatusBadge({ status }: { status: BookingStatus }) {
  return (
    <span className={cn("inline-flex rounded-full px-3 py-1 text-[0.65rem] font-bold uppercase tracking-[0.18em]", statusTone[status])}>
      {BOOKING_STATUSES.find((s) => s.value === status)?.label}
    </span>
  );
}

const fmtDate = (d: string) => format(parseISO(d), "d MMM yyyy");
const fmtDateTime = (d: string) => format(parseISO(d), "d MMM yyyy · HH:mm");

function useIsAdmin() {
  return useQuery({
    queryKey: ["is-admin"],
    queryFn: async () => {
      const { data: u } = await supabase.auth.getUser();
      if (!u.user) return { admin: false, email: null as string | null };
      const { data, error } = await supabase.from("user_roles").select("role").eq("user_id", u.user.id).eq("role", "admin").maybeSingle();
      if (error) throw error;
      return { admin: !!data, email: u.user.email ?? null };
    },
  });
}

function AdminPage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const role = useIsAdmin();

  const signOut = async () => {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  };

  return (
    <section className="min-h-screen px-4 pb-20 pt-28 md:px-10 md:pt-32">
      <div className="mx-auto max-w-[1600px]">
        <div className="flex flex-col justify-between gap-6 md:flex-row md:items-end">
          <div>
            <p className="eyebrow text-primary">Team dashboard</p>
            <h1 className="font-display mt-3 text-6xl md:text-8xl">Booking requests</h1>
          </div>
          <div className="flex items-center gap-3">
            {role.data?.email && <span className="hidden text-sm text-muted-foreground sm:inline">{role.data.email}</span>}
            <Button variant="ghostLight" size="lg" onClick={signOut}>
              <LogOut /> Sign out
            </Button>
          </div>
        </div>

        {role.isPending ? (
          <div className="mt-12 grid gap-3">
            {[0, 1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-16 w-full bg-muted" />
            ))}
          </div>
        ) : role.isError ? (
          <p className="mt-12 text-destructive">Couldn't verify your access. Please refresh.</p>
        ) : !role.data?.admin ? (
          <div className="mt-16 max-w-lg rounded-sm border border-border p-8">
            <h2 className="font-display text-4xl">No access</h2>
            <p className="mt-3 text-muted-foreground">
              This account isn't an admin. Booking requests are only visible to the artist's team. Ask the account owner to grant you access.
            </p>
          </div>
        ) : (
          <Dashboard />
        )}
      </div>
    </section>
  );
}

function Dashboard() {
  const [status, setStatus] = useState<string>("all");
  const [eventType, setEventType] = useState<string>("all");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [q, setQ] = useState("");
  const [selected, setSelected] = useState<Booking | null>(null);

  const bookings = useQuery({
    queryKey: ["bookings"],
    queryFn: async () => {
      const { data, error } = await supabase.from("bookings").select("*").order("created_at", { ascending: false }).limit(1000);
      if (error) throw error;
      return data;
    },
  });

  const rows = useMemo(() => {
    const term = q.trim().toLowerCase();
    return (bookings.data ?? []).filter((b) => {
      if (status !== "all" && b.status !== status) return false;
      if (eventType !== "all" && b.event_type !== eventType) return false;
      if (from && b.event_date < from) return false;
      if (to && b.event_date > to) return false;
      if (term && ![b.full_name, b.email, b.phone, b.event_location, b.company ?? ""].some((v) => v.toLowerCase().includes(term))) return false;
      return true;
    });
  }, [bookings.data, status, eventType, from, to, q]);

  const counts = useMemo(() => {
    const c: Record<string, number> = { all: bookings.data?.length ?? 0 };
    for (const s of BOOKING_STATUSES) c[s.value] = 0;
    for (const b of bookings.data ?? []) c[b.status] = (c[b.status] ?? 0) + 1;
    return c;
  }, [bookings.data]);

  const exportCsv = () => {
    const header = ["Received", "Status", "Name", "Email", "Phone", "Company", "Event type", "Event date", "Location", "Guests", "Duration", "Budget", "Discovery", "Message", "Notes"];
    const esc = (v: unknown) => `"${String(v ?? "").replace(/"/g, '""')}"`;
    const lines = rows.map((b) =>
      [b.created_at, b.status, b.full_name, b.email, b.phone, b.company, eventTypeLabel(b.event_type), b.event_date, b.event_location, b.guest_count, b.duration, b.budget_range, b.discovery_source, b.message, b.admin_notes].map(esc).join(","),
    );
    const blob = new Blob([[header.map(esc).join(","), ...lines].join("\n")], { type: "text/csv" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `percu-arabixx-bookings-${format(new Date(), "yyyy-MM-dd")}.csv`;
    a.click();
    URL.revokeObjectURL(a.href);
  };

  return (
    <>
      {/* Status summary */}
      <div className="mt-12 grid grid-cols-3 gap-px overflow-hidden rounded-sm border border-border bg-border md:grid-cols-6">
        {[{ value: "all", label: "All" }, ...BOOKING_STATUSES].map((s) => (
          <button
            key={s.value}
            type="button"
            onClick={() => setStatus(s.value)}
            className={cn("bg-background p-4 text-left transition-colors md:p-6", status === s.value && "bg-card")}
          >
            <span className="eyebrow text-muted-foreground">{s.label}</span>
            <span className={cn("font-display mt-2 block text-4xl md:text-5xl", status === s.value && "text-primary")}>{counts[s.value] ?? 0}</span>
          </button>
        ))}
      </div>

      {/* Filters */}
      <div className="mt-6 grid gap-3 md:grid-cols-[1fr_200px_200px_160px_160px_auto]">
        <label className="relative">
          <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search name, email, phone, location" className="h-11 w-full rounded-sm border border-input bg-transparent pl-9 pr-3 text-sm focus:border-primary focus:outline-none" />
        </label>
        <Select value={status} onValueChange={setStatus}>
          <SelectTrigger className="h-11 rounded-sm"><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All statuses</SelectItem>
            {BOOKING_STATUSES.map((s) => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={eventType} onValueChange={setEventType}>
          <SelectTrigger className="h-11 rounded-sm"><SelectValue placeholder="Event type" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All event types</SelectItem>
            {EVENT_TYPES.map((t) => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}
          </SelectContent>
        </Select>
        <label className="flex flex-col">
          <span className="sr-only">Event date from</span>
          <input type="date" value={from} onChange={(e) => setFrom(e.target.value)} className="h-11 rounded-sm border border-input bg-transparent px-3 text-sm [color-scheme:dark] focus:border-primary focus:outline-none" aria-label="Event date from" />
        </label>
        <label className="flex flex-col">
          <span className="sr-only">Event date to</span>
          <input type="date" value={to} onChange={(e) => setTo(e.target.value)} className="h-11 rounded-sm border border-input bg-transparent px-3 text-sm [color-scheme:dark] focus:border-primary focus:outline-none" aria-label="Event date to" />
        </label>
        <div className="flex gap-2">
          <Button variant="outline" className="h-11 rounded-sm bg-transparent" onClick={() => bookings.refetch()} aria-label="Refresh">
            <RefreshCw className={cn(bookings.isFetching && "animate-spin")} />
          </Button>
          <Button variant="outline" className="h-11 rounded-sm bg-transparent" onClick={exportCsv} disabled={!rows.length}>
            <Download /> CSV
          </Button>
        </div>
      </div>

      {/* Table */}
      <div className="mt-6 overflow-hidden rounded-sm border border-border">
        {bookings.isPending ? (
          <div className="grid gap-px">
            {[0, 1, 2, 3, 4].map((i) => <Skeleton key={i} className="h-14 rounded-none bg-muted" />)}
          </div>
        ) : bookings.isError ? (
          <div className="p-10 text-center">
            <p className="text-destructive">Couldn't load booking requests.</p>
            <Button variant="ghostLight" className="mt-4" onClick={() => bookings.refetch()}>Try again</Button>
          </div>
        ) : rows.length === 0 ? (
          <div className="flex flex-col items-center gap-3 p-16 text-center">
            <Inbox className="size-10 text-muted-foreground" />
            <p className="font-display text-3xl">{bookings.data.length ? "No matches" : "No requests yet"}</p>
            <p className="max-w-sm text-sm text-muted-foreground">
              {bookings.data.length ? "Try clearing a filter." : "When someone fills in the booking form, their request will appear here."}
            </p>
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow className="hover:bg-transparent">
                <TableHead>Received</TableHead>
                <TableHead>Client</TableHead>
                <TableHead>Event</TableHead>
                <TableHead>Event date</TableHead>
                <TableHead className="hidden lg:table-cell">Location</TableHead>
                <TableHead className="hidden xl:table-cell">Guests</TableHead>
                <TableHead className="hidden xl:table-cell">Budget</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {rows.map((b) => (
                <TableRow key={b.id} className="cursor-pointer" onClick={() => setSelected(b)}>
                  <TableCell className="whitespace-nowrap text-muted-foreground">{fmtDateTime(b.created_at)}</TableCell>
                  <TableCell>
                    <div className="font-semibold">{b.full_name}</div>
                    <div className="text-xs text-muted-foreground">{b.email}</div>
                  </TableCell>
                  <TableCell>{eventTypeLabel(b.event_type)}</TableCell>
                  <TableCell className="whitespace-nowrap">{fmtDate(b.event_date)}</TableCell>
                  <TableCell className="hidden lg:table-cell">{b.event_location}</TableCell>
                  <TableCell className="hidden xl:table-cell">{b.guest_count ?? "—"}</TableCell>
                  <TableCell className="hidden xl:table-cell">{b.budget_range ?? "—"}</TableCell>
                  <TableCell><StatusBadge status={b.status} /></TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </div>

      <BookingSheet booking={selected} onClose={() => setSelected(null)} onSaved={(b) => setSelected(b)} />
    </>
  );
}

function Detail({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div>
      <dt className="eyebrow text-muted-foreground">{label}</dt>
      <dd className="mt-1 whitespace-pre-wrap text-foreground">{children || "—"}</dd>
    </div>
  );
}

function BookingSheet({ booking, onClose, onSaved }: { booking: Booking | null; onClose: () => void; onSaved: (b: Booking) => void }) {
  const queryClient = useQueryClient();
  const [notes, setNotes] = useState<string | null>(null);

  const update = useMutation({
    mutationFn: async (patch: Partial<Pick<Booking, "status" | "admin_notes">>) => {
      if (!booking) throw new Error("No booking");
      const { data, error } = await supabase.from("bookings").update(patch).eq("id", booking.id).select().single();
      if (error) throw error;
      return data;
    },
    onSuccess: (data) => {
      queryClient.setQueryData<Booking[]>(["bookings"], (old) => old?.map((b) => (b.id === data.id ? data : b)));
      onSaved(data);
      toast.success("Saved");
    },
    onError: () => toast.error("Couldn't save. Please try again."),
  });

  const phoneDigits = booking?.phone.replace(/[^\d]/g, "") ?? "";

  return (
    <Sheet
      open={!!booking}
      onOpenChange={(o) => {
        if (!o) {
          onClose();
          setNotes(null);
        }
      }}
    >
      <SheetContent className="w-full overflow-y-auto border-border bg-background sm:max-w-xl">
        {booking && (
          <>
            <SheetHeader className="text-left">
              <p className="eyebrow text-primary">{eventTypeLabel(booking.event_type)} · {fmtDate(booking.event_date)}</p>
              <SheetTitle className="font-display text-5xl">{booking.full_name}</SheetTitle>
              <p className="text-xs text-muted-foreground">Received {fmtDateTime(booking.created_at)}</p>
            </SheetHeader>

            <div className="mt-6 flex flex-wrap gap-2">
              <Button asChild variant="hero" size="sm" className="h-10 px-5">
                <a href={`https://wa.me/${phoneDigits}`} target="_blank" rel="noreferrer"><MessageCircle /> WhatsApp</a>
              </Button>
              <Button asChild variant="ghostLight" size="sm" className="h-10 px-5">
                <a href={`mailto:${booking.email}?subject=${encodeURIComponent("Your Percu Arabixx booking request")}`}><Mail /> Email</a>
              </Button>
            </div>

            <div className="mt-8">
              <span className="eyebrow text-muted-foreground">Status</span>
              <div className="mt-3 flex flex-wrap gap-2">
                {BOOKING_STATUSES.map((s) => (
                  <button
                    key={s.value}
                    type="button"
                    disabled={update.isPending}
                    onClick={() => s.value !== booking.status && update.mutate({ status: s.value })}
                    className={cn(
                      "rounded-full border px-4 py-2 text-xs font-bold uppercase tracking-[0.15em] transition-colors",
                      booking.status === s.value ? "border-primary bg-primary text-primary-foreground" : "border-border hover:border-foreground/50",
                    )}
                  >
                    {s.label}
                  </button>
                ))}
              </div>
            </div>

            <dl className="mt-8 grid grid-cols-2 gap-6">
              <Detail label="Email">{booking.email}</Detail>
              <Detail label="Phone / WhatsApp">{booking.phone}</Detail>
              <Detail label="Company">{booking.company}</Detail>
              <Detail label="Location">{booking.event_location}</Detail>
              <Detail label="Guests">{booking.guest_count}</Detail>
              <Detail label="Duration">{booking.duration}</Detail>
              <Detail label="Budget">{booking.budget_range}</Detail>
              <Detail label="Discovered via">{booking.discovery_source}</Detail>
              <div className="col-span-2">
                <Detail label="Message">{booking.message}</Detail>
              </div>
            </dl>

            <div className="mt-8">
              <label className="eyebrow text-muted-foreground" htmlFor="notes">Team notes (private)</label>
              <Textarea
                id="notes"
                className="mt-3 min-h-28 rounded-sm bg-transparent"
                value={notes ?? booking.admin_notes ?? ""}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Quote sent, follow-up date…"
              />
              <Button
                className="mt-3"
                variant="hero"
                size="sm"
                disabled={update.isPending || notes === null}
                onClick={() => update.mutate({ admin_notes: notes ?? "" })}
              >
                {update.isPending && <Loader2 className="animate-spin" />} Save notes
              </Button>
            </div>
          </>
        )}
      </SheetContent>
    </Sheet>
  );
}
