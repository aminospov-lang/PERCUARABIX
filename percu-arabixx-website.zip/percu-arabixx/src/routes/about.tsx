import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/site/PageHeader";
import { Intro } from "@/components/site/Intro";
import { Venues, Voices } from "@/components/site/Proof";
import { InstagramSection } from "@/components/site/InstagramSection";
import { ContactCTA, SiteFooter } from "@/components/site/ContactCTA";
import { photos } from "@/lib/media";

const TITLE = "About — Percu Arabixx (Larbi Jerkech), Percussionist";
const DESCRIPTION = "Meet Percu Arabixx, the stage name of Moroccan percussionist Larbi Jerkech — live djembe, crowd interaction and stage presence for unforgettable events.";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "profile" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AboutPage,
});

function AboutPage() {
  return (
    <>
      <PageHeader eyebrow="About" title="Larbi" accent="Jerkech." image={photos.laser1} intro="Percussionist. Performer. The beat you feel before you see where it's coming from." />
      <Intro full />
      <Voices />
      <Venues />
      <InstagramSection />
      <ContactCTA />
      <SiteFooter />
    </>
  );
}
