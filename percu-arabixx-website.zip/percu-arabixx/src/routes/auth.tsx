import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { z } from "zod";
import { Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { Button } from "@/components/ui/button";

const searchSchema = z.object({ redirect: z.string().optional() });

const safePath = (p?: string) => (p && p.startsWith("/") && !p.startsWith("//") ? p : "/admin");

export const Route = createFileRoute("/auth")({
  validateSearch: searchSchema,
  head: () => ({
    meta: [
      { title: "Team sign in — Percu Arabixx" },
      { name: "description", content: "Sign in to manage Percu Arabixx booking requests." },
      { property: "og:title", content: "Team sign in — Percu Arabixx" },
      { property: "og:description", content: "Sign in to manage Percu Arabixx booking requests." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AuthPage,
});

const input =
  "w-full border-0 border-b border-input bg-transparent px-0 py-3 text-lg text-foreground placeholder:text-muted-foreground/60 focus:border-primary focus:outline-none";

function AuthPage() {
  const { redirect } = Route.useSearch();
  const navigate = useNavigate();
  const [mode, setMode] = useState<"signin" | "signup" | "forgot">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<{ kind: "ok" | "error"; text: string } | null>(null);

  useEffect(() => {
    if (redirect) sessionStorage.setItem("pa-auth-redirect", safePath(redirect));
    supabase.auth.getUser().then(({ data }) => {
      if (data.user) navigate({ to: safePath(sessionStorage.getItem("pa-auth-redirect") ?? redirect), replace: true });
    });
  }, [redirect, navigate]);

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setMessage(null);
    try {
      if (mode === "signin") {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        const to = safePath(sessionStorage.getItem("pa-auth-redirect") ?? redirect);
        sessionStorage.removeItem("pa-auth-redirect");
        navigate({ to, replace: true });
      } else if (mode === "signup") {
        const { error } = await supabase.auth.signUp({ email, password, options: { emailRedirectTo: `${window.location.origin}/admin` } });
        if (error) throw error;
        setMessage({ kind: "ok", text: "Check your inbox to confirm your email, then sign in." });
        setMode("signin");
      } else {
        const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo: `${window.location.origin}/reset-password` });
        if (error) throw error;
        setMessage({ kind: "ok", text: "If an account exists for this email, a reset link is on its way." });
      }
    } catch (err) {
      setMessage({ kind: "error", text: err instanceof Error ? err.message : "Something went wrong" });
    } finally {
      setBusy(false);
    }
  };

  const google = async () => {
    setMessage(null);
    const result = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin + "/auth" });
    if (result.error) {
      setMessage({ kind: "error", text: result.error.message });
      return;
    }
    if (result.redirected) return;
    const to = safePath(sessionStorage.getItem("pa-auth-redirect") ?? redirect);
    sessionStorage.removeItem("pa-auth-redirect");
    navigate({ to, replace: true });
  };

  return (
    <section className="bg-stage-glow flex min-h-screen items-center justify-center px-5 py-32">
      <div className="w-full max-w-md">
        <p className="eyebrow text-primary">Team area</p>
        <h1 className="font-display mt-4 text-7xl">
          {mode === "signin" ? "Sign in" : mode === "signup" ? "Create account" : "Reset password"}
        </h1>
        <p className="mt-4 text-sm text-muted-foreground">Booking requests are private and only visible to the artist's team.</p>

        {mode !== "forgot" && (
          <Button type="button" variant="ghostLight" size="xl" className="mt-10 w-full" onClick={google}>
            Continue with Google
          </Button>
        )}

        <form onSubmit={onSubmit} className="mt-8 flex flex-col gap-6">
          <label className="flex flex-col">
            <span className="eyebrow text-muted-foreground">Email</span>
            <input className={input} type="email" required value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" />
          </label>
          {mode !== "forgot" && (
            <label className="flex flex-col">
              <span className="eyebrow text-muted-foreground">Password</span>
              <input className={input} type="password" required minLength={8} value={password} onChange={(e) => setPassword(e.target.value)} autoComplete={mode === "signin" ? "current-password" : "new-password"} />
            </label>
          )}
          {message && (
            <p className={message.kind === "ok" ? "text-sm text-success" : "text-sm text-destructive"} role="alert">
              {message.text}
            </p>
          )}
          <Button type="submit" variant="hero" size="xl" disabled={busy}>
            {busy && <Loader2 className="animate-spin" />}
            {mode === "signin" ? "Sign in" : mode === "signup" ? "Create account" : "Send reset link"}
          </Button>
        </form>

        <div className="mt-8 flex flex-wrap justify-between gap-4 text-sm text-muted-foreground">
          {mode === "signin" ? (
            <>
              <button type="button" className="hover:text-foreground" onClick={() => setMode("signup")}>Create an account</button>
              <button type="button" className="hover:text-foreground" onClick={() => setMode("forgot")}>Forgot password?</button>
            </>
          ) : (
            <button type="button" className="hover:text-foreground" onClick={() => setMode("signin")}>Back to sign in</button>
          )}
        </div>
      </div>
    </section>
  );
}
