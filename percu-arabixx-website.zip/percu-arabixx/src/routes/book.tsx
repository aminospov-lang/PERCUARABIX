import { createFileRoute } from "@tanstack/react-router";
import { Instagram, MessageCircle } from "lucide-react";
import { BookingForm } from "@/components/site/BookingForm";
import { SiteFooter } from "@/components/site/ContactCTA";
import { artist, photos } from "@/lib/media";

const TITLE = "Book Percu Arabixx — Live Percussion Booking";
const DESCRIPTION = "Request Percu Arabixx for your wedding, private event, club night, festival or brand activation. Share your date and details — the team replies shortly.";

export const Route = createFileRoute("/book")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: BookPage,
});

function BookPage() {
  return (
    <>
      <section className="relative overflow-hidden px-5 pb-10 pt-32 md:px-10 md:pt-44">
        <div className="absolute inset-y-0 right-0 hidden w-[34%] lg:block">
          <img src={photos.djembe.src} srcSet={photos.djembe.srcSet} sizes="34vw" alt={photos.djembe.alt} className="h-full w-full object-cover opacity-60" />
          <div className="absolute inset-0 bg-gradient-to-r from-background via-background/60 to-transparent" />
        </div>
        <div className="relative mx-auto max-w-[1600px]">
          <p className="eyebrow text-primary">Booking</p>
          <h1 className="font-display mt-5 text-[19vw] leading-[0.82] md:text-[11vw] xl:text-[11rem]">
            Book
            <br />
            <span className="font-editorial normal-case text-primary">Percu Arabixx</span>
          </h1>
          <p className="mt-8 max-w-lg text-lg text-foreground/75">Three short steps. Tell us about the event and the team will come back to you with availability.</p>
          <div className="mt-6 flex flex-wrap gap-6">
            <a href={artist.whatsappUrl} target="_blank" rel="noreferrer" className="eyebrow flex items-center gap-2 text-foreground/80 hover:text-primary">
              <MessageCircle className="size-4 text-primary" /> WhatsApp {artist.phoneDisplay}
            </a>
            <a href={artist.instagramUrl} target="_blank" rel="noreferrer" className="eyebrow flex items-center gap-2 text-foreground/80 hover:text-primary">
              <Instagram className="size-4 text-primary" /> {artist.instagramHandle}
            </a>
          </div>
        </div>
      </section>
      <section className="relative px-5 pb-32 pt-10 md:px-10">
        <div className="relative mx-auto max-w-[1600px] lg:pr-[34%]">
          <BookingForm />
        </div>
      </section>
      <SiteFooter />
    </>
  );
}
