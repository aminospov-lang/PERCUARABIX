import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/site/PageHeader";
import { EventsSection } from "@/components/site/EventsSection";
import { Venues } from "@/components/site/Proof";
import { ContactCTA, SiteFooter } from "@/components/site/ContactCTA";
import { photos } from "@/lib/media";

const TITLE = "Events — Book Percu Arabixx for Weddings, Clubs & Brands";
const DESCRIPTION = "Live percussion for private events, weddings, corporate events, clubs and nightlife, festivals and brand activations — shaped around your room.";

export const Route = createFileRoute("/events")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: EventsPage,
});

function EventsPage() {
  return (
    <>
      <PageHeader
        eyebrow="Events"
        title="Your event,"
        accent="his rhythm."
        image={photos.weddingColor}
        intro="From intimate celebrations to packed dance floors — choose the setting, and the performance is built around it."
      />
      <EventsSection />
      <Venues />
      <ContactCTA />
      <SiteFooter />
    </>
  );
}
