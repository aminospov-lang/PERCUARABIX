import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/site/PageHeader";
import { ExperienceSequence } from "@/components/site/ExperienceSequence";
import { WatchSection } from "@/components/site/WatchSection";
import { Voices } from "@/components/site/Proof";
import { ContactCTA, SiteFooter } from "@/components/site/ContactCTA";
import { photos } from "@/lib/media";

const TITLE = "The Experience — Percu Arabixx Live Percussion";
const DESCRIPTION = "Feel a Percu Arabixx performance: live djembe above the crowd, peak-moment energy and real footage from weddings, lounges and club nights.";

export const Route = createFileRoute("/experience")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ExperiencePage,
});

function ExperiencePage() {
  return (
    <>
      <PageHeader
        eyebrow="The experience"
        title="Feel it"
        accent="before you hear it."
        image={photos.shokoWide}
        intro="Live performance, event energy, the crowd, the moment, the rhythm — five chapters of a night with Percu Arabixx."
      />
      <ExperienceSequence />
      <WatchSection />
      <Voices />
      <ContactCTA />
      <SiteFooter />
    </>
  );
}
