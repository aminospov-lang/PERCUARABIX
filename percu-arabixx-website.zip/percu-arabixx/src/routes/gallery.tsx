import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/site/PageHeader";
import { GalleryArchive } from "@/components/site/Gallery";
import { InstagramSection } from "@/components/site/InstagramSection";
import { ContactCTA, SiteFooter } from "@/components/site/ContactCTA";
import { photos } from "@/lib/media";

const TITLE = "Gallery — Percu Arabixx Visual Archive";
const DESCRIPTION = "Photographs and stills from Percu Arabixx performances: lasers, lanterns, wedding floors and club nights.";

export const Route = createFileRoute("/gallery")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: GalleryPage,
});

function GalleryPage() {
  return (
    <>
      <PageHeader eyebrow="Visual archive" title="Frames" accent="from the floor." image={photos.laser2} intro="Tap any image to open it full screen." />
      <GalleryArchive />
      <InstagramSection />
      <ContactCTA />
      <SiteFooter />
    </>
  );
}
