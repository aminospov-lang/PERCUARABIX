import { createFileRoute } from "@tanstack/react-router";
import { Hero } from "@/components/site/Hero";
import { Intro } from "@/components/site/Intro";
import { ExperienceSequence } from "@/components/site/ExperienceSequence";
import { EventsSection } from "@/components/site/EventsSection";
import { GalleryStrip } from "@/components/site/Gallery";
import { WatchSection } from "@/components/site/WatchSection";
import { Venues, Voices } from "@/components/site/Proof";
import { InstagramSection } from "@/components/site/InstagramSection";
import { ContactCTA, SiteFooter } from "@/components/site/ContactCTA";
import { Marquee } from "@/components/site/Marquee";

const TITLE = "Percu Arabixx — Live Percussion & Event Performance";
const DESCRIPTION =
  "Percu Arabixx (Larbi Jerkech) is a Moroccan live percussionist bringing djembe energy, crowd interaction and stage presence to weddings, private events, clubs and brand experiences.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: TITLE },
      { name: "twitter:description", content: DESCRIPTION },
    ],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Person",
          name: "Percu Arabixx",
          alternateName: "Larbi Jerkech",
          jobTitle: "Percussionist",
          description: DESCRIPTION,
          sameAs: ["https://www.instagram.com/percu.arabixx/"],
        }),
      },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <>
      <Hero />
      <Marquee
        items={["Live percussion", "Weddings", "Private events", "Clubs & nightlife", "Brand experiences", "Festivals"]}
        className="border-y border-border bg-primary py-4 text-primary-foreground"
        itemClassName="font-display text-3xl md:text-4xl"
      />
      <Intro />
      <ExperienceSequence />
      <EventsSection />
      <GalleryStrip />
      <WatchSection />
      <Voices />
      <Venues />
      <InstagramSection />
      <ContactCTA />
      <SiteFooter />
    </>
  );
}
