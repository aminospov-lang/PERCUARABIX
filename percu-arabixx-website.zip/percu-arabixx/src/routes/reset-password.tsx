import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/reset-password")({
  head: () => ({
    meta: [
      { title: "Set a new password — Percu Arabixx" },
      { name: "description", content: "Choose a new password for the Percu Arabixx team area." },
      { property: "og:title", content: "Set a new password — Percu Arabixx" },
      { property: "og:description", content: "Choose a new password for the Percu Arabixx team area." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: ResetPassword,
});

function ResetPassword() {
  const navigate = useNavigate();
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    const { error } = await supabase.auth.updateUser({ password });
    setBusy(false);
    if (error) return setError(error.message);
    navigate({ to: "/admin", replace: true });
  };

  return (
    <section className="flex min-h-screen items-center justify-center px-5 py-32">
      <form onSubmit={onSubmit} className="w-full max-w-md">
        <h1 className="font-display text-6xl">New password</h1>
        <label className="mt-10 flex flex-col">
          <span className="eyebrow text-muted-foreground">Password</span>
          <input
            type="password"
            required
            minLength={8}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoComplete="new-password"
            className="w-full border-0 border-b border-input bg-transparent px-0 py-3 text-lg focus:border-primary focus:outline-none"
          />
        </label>
        {error && <p className="mt-4 text-sm text-destructive">{error}</p>}
        <Button type="submit" variant="hero" size="xl" className="mt-8 w-full" disabled={busy}>
          Save password
        </Button>
      </form>
    </section>
  );
}
