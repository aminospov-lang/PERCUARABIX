import { describe, expect, it } from "vitest";
import {
  EVENT_TYPES,
  isLikelySpam,
  makeBookingSchema,
  MAX_REQUESTS_PER_EMAIL_PER_HOUR,
  MIN_FILL_TIME_MS,
} from "@/lib/booking-schema";

const now = new Date("2026-10-22T10:00:00");
const valid = {
  full_name: "Sara Benali",
  email: "Sara@Example.com",
  phone: "+212 600 000 000",
  event_type: "wedding",
  event_date: "2026-12-12",
  event_location: "Marrakech",
  started_at: now.getTime() - 60_000,
};

describe("booking form rules", () => {
  it("offers exactly the eight requested event types", () => {
    expect(EVENT_TYPES.map((e) => e.label)).toEqual([
      "Private Event",
      "Wedding",
      "Corporate Event",
      "Club",
      "Festival",
      "Brand Activation",
      "Concert",
      "Other",
    ]);
  });

  it("accepts a complete request and normalises the email", () => {
    const parsed = makeBookingSchema(now).parse(valid);
    expect(parsed.email).toBe("sara@example.com");
  });

  it("rejects an event date in the past", () => {
    const result = makeBookingSchema(now).safeParse({ ...valid, event_date: "2026-10-21" });
    expect(result.success).toBe(false);
  });

  it("requires name, email, phone, event type, date and location", () => {
    const result = makeBookingSchema(now).safeParse({ started_at: valid.started_at });
    expect(result.success).toBe(false);
    if (!result.success) {
      const fields = Object.keys(result.error.flatten().fieldErrors).sort();
      expect(fields).toEqual(["email", "event_date", "event_location", "event_type", "full_name", "phone"]);
    }
  });

  it("rejects an unknown event type", () => {
    const result = makeBookingSchema(now).safeParse({ ...valid, event_type: "birthday" });
    expect(result.success).toBe(false);
  });
});

describe("spam protection", () => {
  it("flags a filled honeypot field", () => {
    expect(isLikelySpam({ website: "http://spam.example", started_at: 0 }, 100_000)).toBe(true);
  });

  it("flags forms submitted faster than a human could fill them", () => {
    expect(isLikelySpam({ started_at: 10_000 }, 10_000 + MIN_FILL_TIME_MS - 1)).toBe(true);
  });

  it("lets a normal submission through", () => {
    expect(isLikelySpam({ website: "", started_at: 10_000 }, 10_000 + MIN_FILL_TIME_MS + 1)).toBe(false);
  });

  it("allows at most 3 requests per email per hour", () => {
    expect(MAX_REQUESTS_PER_EMAIL_PER_HOUR).toBe(3);
  });
});
